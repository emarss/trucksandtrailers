
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="Trucks, Trailer, market, buy trucks, buy trailers, Zimbabwe" />
<meta name="description" content="A common market for trucks, trailers, farm equipmemnt, machinery, spares and services.">
<meta name="author" content="emarss.co.zw">

<!-- Favicons-->
<link rel="shortcut icon" href="img/favicon.png" type="image/png">

<!-- GOOGLE WEB FONT -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/style.css') }}" rel="stylesheet">
<link href="{{ asset('css/vendors.css') }}" rel="stylesheet">

<!-- YOUR CUSTOM CSS -->
<link href="{{ asset('css/custom.css') }}" rel="stylesheet">
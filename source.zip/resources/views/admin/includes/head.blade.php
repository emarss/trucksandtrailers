<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- App CSS -->
<link type="text/css" href="{{ asset('admin/css/preconnect.css') }}" rel="stylesheet">
<link type="text/css" href="{{ asset('admin/css/app.css') }}" rel="stylesheet">
<link type="text/css" href="{{ asset('admin/css/style.css') }}" rel="stylesheet">

<!-- Simplebar -->
<link type="text/css" href="{{ asset('admin/vendor/simplebar.css') }}" rel="stylesheet">
<link type="text/css" href="{{ asset('admin/css/vendor-bootstrap-datatables.css') }}" rel="stylesheet">

<!-- Favicon -->
<link rel="shortcut icon" href="{{ asset('img/logos/logo-only.png') }}" type="image/x-icon" />
<link rel="apple-touch-icon" href="{{ asset('img/logos/logo-only.png') }}">



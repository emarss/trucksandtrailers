<div class="post--item post--single post--type-video post--title-large">
    <div class="post--img">
        <a href="<?php echo e(route('videos-gallery.show', $video->id)); ?>" class="thumb"><img src="<?php echo e($video->thumbnail()); ?>" alt=""></a>

        <div class="post--info">
            <ul class="nav meta">
                <li><a><?php echo e($video->created_at->diffForHumans()); ?></a></li>
            </ul>

            <div class="title">
                <h2 class="h4"><a href="<?php echo e(route('videos-gallery.show', $video->id)); ?>" class="btn-link"><?php echo Str::limit($video->description); ?></a></h2>
            </div>
        </div>

    </div>
</div><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/video-format-one.blade.php ENDPATH**/ ?>
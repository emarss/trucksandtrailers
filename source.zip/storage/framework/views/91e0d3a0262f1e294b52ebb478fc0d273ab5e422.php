<div class="post--item post--layout-1 post--title-large">
    <div class="post--img">
        <a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>" alt=""></a>
        <?php
            $category = $post->categories()->random()
        ?>
        <a href="<?php echo e(route("blog.search", $category->category)); ?>" class="cat"><?php echo e(str_replace('_', " ", $category->category)); ?></a>
        <div class="post--info">
            <ul class="nav meta">
                <li><a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a></li>
                <li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
            </ul>
            <div class="title">
                <h2 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title, 70)); ?></a></h2>
            </div>
        </div>
    </div>
    <div class="post--content">
        <p><?php echo e($post->except()); ?></p>
    </div>
    <div class="post--action">
        <a href="<?php echo e(route('blog.show', $post->id)); ?>">Continue Reading...</a>
    </div>
</div>
<?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/post-format-one.blade.php ENDPATH**/ ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($pageTitle); ?>

                <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
            </h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm table-striped" id="data-table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col" class="text-center">#</th>
                            <th scope="col" class="text-center">Title</th>
                            <th scope="col" class="text-center">Skills</th>
                            <th scope="col" class="text-center">Created By</th>
                            <th scope="col" class="text-center">Last Updated</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th class="align-middle text-center" scope="row"><?php echo e($project->id); ?></th>
                                <td><?php echo Str::limit($project->title, 40); ?></th>
                                <td>
                                    <select class="custom-select">
                                        <?php $__currentLoopData = $project->skills(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($loop->first): ?> selected="" <?php endif; ?>><?php echo e(ucwords($skill)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </th>
                                <td><?php echo e($project->user->name); ?></th>
                                <td><?php echo e($project->updated_at->diffForHumans()); ?></th>
                                <td class="align-middle text-center">
                                    <a href="<?php echo e(route('admin.projects.show', $project->id)); ?>"
                                        class="btn btn-sm btn-primary">Show</a>
                                    <a href="<?php echo e(route('admin.projects.edit', $project->id)); ?>"
                                        class="btn btn-sm btn-primary">Edit</a>
                                    <button onclick="confirmDelete('<?php echo e(route('admin.projects.destroy', $project->id)); ?>')"
                                        class="btn btn-sm btn-danger">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">No projects found. Click <a
                                        href="<?php echo e(route('admin.projects.create')); ?>">this link</a> to create new.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#data-table').DataTable({
            "order": [
                [0, "desc"]
            ]
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/admin/projects/index.blade.php ENDPATH**/ ?>
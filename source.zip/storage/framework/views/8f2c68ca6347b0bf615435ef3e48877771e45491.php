
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($pageTitle); ?>

                <a href="<?php echo e(route('admin.listings.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
            </h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm table-striped" id="data-table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col" class="text-center">#</th>
                            <th scope="col" class="text-center">Name</th>
                            <th scope="col" class="text-center">Status</th>
                            <th scope="col" class="text-center">Price</th>
                            <th scope="col" class="text-center">Category</th>
                            <th scope="col" class="text-center">Last Updated</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th class="align-middle text-center" scope="row"><?php echo e($listing->id); ?></th>
                                <td><?php echo e($listing->name); ?></th>
                                <td>
                                    <span
                                        class="badge <?php echo e($listing->status == 1 ? 'badge-primary' : 'badge-danger'); ?> py-1"><?php echo e($listing->getStatus()); ?></span>
                                    </th>
                                <td><?php echo e($listing->price); ?> <?php echo e($listing->currency); ?></th>
                                <td><?php echo e(ucwords($listing->getCategory())); ?></th>
                                <td><?php echo e($listing->updated_at->diffForHumans()); ?></th>
                                <td class="align-middle text-center">
                                    <a href="<?php echo e(route('admin.listings.show', $listing->id)); ?>"
                                        class="btn btn-sm btn-primary">Show</a>
                                    <a href="<?php echo e(route('admin.listings.edit', $listing->id)); ?>"
                                        class="btn btn-sm btn-primary">Edit</a>
                                    <button
                                        onclick="confirmDelete('<?php echo e(route('admin.listings.destroy', $listing->id)); ?>')"
                                        class="btn btn-sm btn-danger">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">No listings found. Click <a
                                        href="<?php echo e(route('admin.listings.create')); ?>">this link</a> to create new.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#data-table').DataTable({
            "order": [
                [0, "desc"]
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/admin/listings/index.blade.php ENDPATH**/ ?>
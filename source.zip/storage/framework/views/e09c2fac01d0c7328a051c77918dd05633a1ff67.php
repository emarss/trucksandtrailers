<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">


                        <h1 class="text-dark font-weight-bold text-8">Our News & Updates</h1>
                        <span class="sub-title text-dark">Check out our Latest News & Updates!</span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="active">Blog</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-4">

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="blog-posts single-post">

                        <article class="post post-large blog-single-post border-0 m-0 p-0">
                            <div class="post-image ml-0">
                                <a href="<?php echo e(route('blog.user', $post->user_id)); ?>">
                                    <img src="<?php echo e($post->featuredImage()); ?>" class="w-100 img-fluid img-thumbnail img-thumbnail-no-borders rounded-0" alt="" />
                                </a>
                            </div>

                            <div class="post-date ml-0">
                                <span class="day"><?php echo e($post->created_at->format('d')); ?></span>
                                <span class="month"><?php echo e($post->created_at->format('M')); ?></span>
                            </div>

                            <div class="post-content ml-0">

                                <h2 class="font-weight-semi-bold"><a href=""><?php echo e($post->title); ?></a></h2>

                                <div class="post-meta">
                                    <span><i class="far fa-user"></i> By <a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a> </span>
                                    <span><i class="far fa-folder"></i>
                                        <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('search.category', $category->category)); ?>"><?php echo e(ucwords(str_replace('_', ' ', $category->category))); ?></a>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span>
                                </div>

                                <div class="text-justify">
                                    <?php echo $post->body; ?>

                                </div>

                                <div class="post-meta mt-4">
                                    <span><i class="fa fa-tags"></i>
                                        <?php $__currentLoopData = $post->tags(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('search.tag', $tag)); ?>"><?php echo e($tag); ?></a>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span>
                                </div>



                                <hr>
                                <div class="post-block mt-4 pt-2 post-author">
                                    <h4 class="mb-3">Author</h4>
                                    <div class="img-thumbnail img-thumbnail-no-borders d-block pb-3">
                                        <a href="<?php echo e(route('blog.user', $post->user_id)); ?>">
                                            <img src="<?php echo e($post->user->profile->avatar()); ?>" alt="<?php echo e($post->user->name); ?>" class="rounded-circle" height="53">
                                        </a>
                                    </div>
                                    <p><strong class="name"><a href="<?php echo e(route('blog.user', $post->user_id)); ?>" class="text-4 pb-2 pt-2 d-block"><?php echo e($post->user->name); ?></a></strong></p>
                                    <p><?php echo e($post->user->bio()); ?></p>
                                </div>

                                <hr>


                            </div>
                        </article>

                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/blog-show.blade.php ENDPATH**/ ?>
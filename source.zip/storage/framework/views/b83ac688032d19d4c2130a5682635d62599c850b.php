<header class="header_in">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-12">
                <div id="logo">
                    <a href="/">
                        <img src="<?php echo e(asset('img/logo-long.png')); ?>" height="35" alt="" class="logo_sticky">
                    </a>
                </div>
            </div>
            <div class="col-lg-9 col-12">
                <ul id="top_menu">
                    <li><a href="<?php echo e(route('add_listing')); ?>" class="btn_add">Add Listing</a></li>
                </ul>
                <!-- /top_menu -->
                <a href="#menu" class="btn_mobile">
                    <div class="hamburger hamburger--spin" id="hamburger">
                        <div class="hamburger-box">
                            <div class="hamburger-inner"></div>
                        </div>
                    </div>
                </a>
                <nav id="menu" class="main-menu">
                    <ul>
                        <li><span><a href="<?php echo e(route('add_listing')); ?>" class="btn_add d-lg-none">Add Listing</a></span></li>
                        <li><span><a href="<?php echo e(route('home')); ?>">Home</a></span></li>
                        <li><span><a href="#0">Categories</a></span>
                            <ul>
                                <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('category', $category->category)); ?>"><?php echo e(ucwords($category->category)); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li><span><a href="<?php echo e(route('about')); ?>">About Us</a></span></li>
                        <li><span><a href="<?php echo e(route('contact')); ?>">Contact Us</a></span></li>
                        <li><span><a href="#0">More</a></span>
                            <ul>
                                <li><a href="<?php echo e(route('terms')); ?>">Terms & Conditions</a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
            </div>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
        <!-- search_mobile -->
        <div class="layer"></div>
        <div id="search_mobile">
            <a href="#" class="side_panel"><i class="icon_close"></i></a>
            <form action="<?php echo e(route('search')); ?>" method="POST" class="custom-search-input-2">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input <?php if(isset($prevSearch)): ?> value="<?php echo e($prevSearch); ?>" <?php endif; ?> class="form-control"
                                        name="search" type="text" placeholder="What are you looking for...">
                    <i class="icon_search"></i>
                </div>
               
                <select name="category" class="wide">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(isset($prevCategory)): ?>
                            <?php echo e($prevCategory == $category->id ? 'selected' : ''); ?> <?php endif; ?>
                            value="<?php echo e($category->id); ?>"><?php echo e(ucwords($category->category)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="submit">
            </form>
        </div>
        <!-- /search_mobile -->
</header>
<!-- /header -->
<?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/includes/header.blade.php ENDPATH**/ ?>
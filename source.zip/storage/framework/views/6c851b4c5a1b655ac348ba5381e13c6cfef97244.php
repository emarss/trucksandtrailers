<nav class="drawer drawer--light">
  <div class="drawer-spacer drawer-spacer-border">
    <div class="media text-center">
      <div class="media-body">
        <span class="material-icons">person</span>
        <a href="#" class="h5 pb-2"><?php echo e(auth()->user()->name); ?></a>
      </div>
    </div>
  </div>
  <!-- MENU -->
  <ul class="drawer-menu" id="userMenu" data-children=".drawer-submenu">

    <li class="drawer-menu-item border-o">
      <a href="profile.html">
        <i class="material-icons">account_circle</i>
        <span class="drawer-menu-text"> Profile</span>
      </a>
    </li>
    <li class="drawer-menu-item border-o">
      <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
        <i class="material-icons">exit_to_app</i>
        <span class="drawer-menu-text"> Logout</span>
      </a>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
      </form>
    </li>
  </ul>
</nav><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/includes/sidebar_user.blade.php ENDPATH**/ ?>
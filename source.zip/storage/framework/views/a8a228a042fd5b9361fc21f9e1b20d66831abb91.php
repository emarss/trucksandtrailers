<?php $__env->startSection('content'); ?>

    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <div class="main--content pd--30-0">
                    <div class="post--items-title" data-ajax="tab">
                        <h2 class="h4">Videos Gallery</h2>
                    </div>

                    <div class="post--items post--items-4" data-ajax-content="outer">
                        <ul class="nav row" data-ajax-content="inner">
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="col-md-4 col-12 mt-5">
                                    <?php echo $__env->make('inc.video-format-one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--60 pbottom--30">
                        <?php echo e($videos->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/videos-gallery.blade.php ENDPATH**/ ?>
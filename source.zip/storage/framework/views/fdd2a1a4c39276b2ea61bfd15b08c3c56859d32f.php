
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      	<h4 class="card-title">
        	<?php echo e($pageTitle); ?>

          <a href="<?php echo e(route('admin.documents.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
      	</h4>
    </div>
    <div class="card-body">
      <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <b>Document</b>
                <a href="<?php echo e(route('admin.documents.create', $document->id)); ?>" class="btn btn-primary btn-sm float-right">Download</a>
            </h4>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Tags</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php $__currentLoopData = $document->tags(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-primary py-1"><?php echo e(ucfirst($tag)); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Categories</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php $__currentLoopData = $document->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-primary py-1"><?php echo e(ucwords(str_replace("_", ' ', $category->category))); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Description</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $document->description; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Created By</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($document->user->name); ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Created At</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($document->created_at->diffForHumans()); ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Last Updated</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($document->updated_at->diffForHumans()); ?>

            </p>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/documents/show.blade.php ENDPATH**/ ?>
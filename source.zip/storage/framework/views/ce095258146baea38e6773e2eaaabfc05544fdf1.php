<?php $__env->startSection('content'); ?>
    <!-- Map Start -->
    <iframe class="mtop--30" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30386.96434129073!2d31.030756825450506!3d-17.821256420465133!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1931a502ca86ff65%3A0x28d551c2702058ef!2sAvenues%2C%20Harare!5e0!3m2!1sen!2szw!4v1598865775068!5m2!1sen!2szw" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    <!-- Map End -->

    <!-- Contact Section Start -->
    <div class="contact--section pd--30-0">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-4 ptop--30 pbottom--30">
                    <!-- Contact Info Start -->
                    <div class="contact--info">
                        <ul class="nav">
                            <li>
                                <div class="title">
                                    <h3 class="h5"><i class="fa fa-phone-square"></i>Telephone</h3>
                                </div>

                                <div class="content">
                                    <p><a href="tel:+263 77 467 1339">+263 77 467 1339</a></p>
                                    <p><a href="tel:+263 77 467 1339">+263 77 467 1339</a></p>
                                </div>
                            </li>

                            <li>
                                <div class="title">
                                    <h3 class="h5"><i class="fa fa-envelope-open"></i>E-mail Address</h3>
                                </div>

                                <div class="content">
                                    <p><a href="mailto:info@zhrmp.co.zw">info@zhrmp.co.zw</a></p>
                                    <p><a href="mailto:contact@zhrmp.co.zw">contact@zhrmp.co.zw</a></p>
                                </div>
                            </li>

                            <li>
                                <div class="title">
                                    <h3 class="h5"><i class="fa fa-map-marker"></i>Address</h3>
                                </div>

                                <div class="content">
                                    <p>123 Street, Avenues</p>
                                    <p>Harare, Zimbabwe</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- Contact Info End -->
                </div>

                <div class="col-md-9 col-sm-8 ptop--30 pbottom--30">
                    <!-- Comment Form Start -->
                    <div class="comment--form">
                        <div class="comment-respond">
                            <form action="<?php echo e(route('feedback')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="status"></div>
                                
                                <div class="row">
                                    <div class="col-xs-6 col-xxs-12">
                                        <label>
                                            <span>Name *</span>
                                            <input value="<?php echo e(old('name')); ?>" type="text" required="" name="name" class="form-control" required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="text-danger my-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>

                                        <label>
                                            <span>Email Address *</span>
                                            <input value="<?php echo e(old('email')); ?>" type="email" required="" name="email" class="form-control" required>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="text-danger my-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>

                                        <label>
                                            <span>Website</span>
                                            <input value="<?php echo e(old('website')); ?>" type="url" name="website" class="form-control">
                                            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="text-danger my-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>

                                    <div class="col-xs-6 col-xxs-12">
                                        <label>
                                            <span>Comment *</span>
                                            <textarea required="" name="message" class="form-control" required><?php echo e(old('message')); ?></textarea>
                                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="text-danger my-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>

                                    <div class="col-md-12 text-right">
                                        <button type="submit" class="btn btn-primary">Send Message</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Comment Form End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Contact Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/contact.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <div class="main--content col-md-12" data-sticky-content="true">
                    <div class="sticky-content-inner">
                        <div class="post--items post--items-1 pd--30-0">
                            <h2><?php echo e("Photos: ". ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <ul class="nav row gutter--15">
                                <?php echo $__env->make('inc.photos-partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </div>
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--30 pbottom--60">
                            <?php echo e($photos->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/search-photos.blade.php ENDPATH**/ ?>
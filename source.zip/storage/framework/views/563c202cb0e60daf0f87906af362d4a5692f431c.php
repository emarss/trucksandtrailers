<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div role="main" class="main">
        <div class="owl-carousel owl-carousel-light owl-carousel-light-init-fadeIn owl-theme manual bg-color-light-scale-1 dots-inside dots-horizontal-center show-dots-hover show-dots-xs nav-inside nav-inside-plus nav-light nav-lg nav-font-size-md show-nav-hover rounded-nav mb-0"
            data-plugin-options="{'autoplayTimeout': 3000}" style="height: calc( 100vh - 100px );">
            <div class="owl-stage-outer">
                <div class="owl-stage">

                    <!-- Carousel Slide 1 -->
                    <div class="owl-item position-relative" style="height: calc( 100vh - 100px );">
                        <div class="container position-relative z-index-3 h-100">
                            <div class="row align-items-center h-100">
                                <div class="col-md-9 col-lg-6">
                                    <h1 class="text-color-dark font-weight-extra-bold text-12 line-height-3 mb-3 appear-animation"
                                        data-appear-animation="fadeInLeftShorterPlus" data-appear-animation-delay="500"
                                        data-appear-animation-duration="500ms" data-plugin-options="{'minWindowWidth': 0}">
                                        Emarss Technologies, your partner in Digital Solutions.
                                    </h1>
                                    <p class="text-4-5 text-color-dark font-weight-light mb-4" data-plugin-animated-letters
                                        data-plugin-options="{'startDelay': 600, 'minWindowWidth': 0, 'animationSpeed': 50}">
                                        We transform your ideas to reality.</p>
                                    <a href="<?php echo e(route('contact')); ?>"
                                        class="btn btn-primary btn-modern font-weight-bold text-3 py-3 btn-px-5 mt-2 appear-animation"
                                        data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1000"
                                        data-plugin-options="{'minWindowWidth': 0}">GET STARTED NOW <i
                                            class="fas fa-arrow-right ml-2"></i></a>
                                </div>
                                <div class="col-lg-5 offset-lg-1 d-none d-lg-block">
                                    <div class="position-relative appear-animation"
                                        data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1500"
                                        data-plugin-options="{'minWindowWidth': 0}">
                                        <img src="<?php echo e(asset('img/home2.png')); ?>" class="img-fluid" alt="" />

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Carousel Slide 2 -->
                    <div class="owl-item position-relative" style="height: calc( 100vh - 100px );">
                        <div class="container position-relative z-index-3 h-100">
                            <div class="row align-items-center h-100">
                                <div class="col-lg-5 d-none d-lg-block">
                                    <div class="position-relative appear-animation"
                                        data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1000"
                                        data-plugin-options="{'minWindowWidth': 0}">
                                        <img src="<?php echo e(asset('img/home1.png')); ?>" class="img-fluid" alt="" />
                                    </div>
                                </div>
                                <div class="col-md-9 col-lg-6 offset-lg-1">
                                    <h1 class="text-color-dark font-weight-extra-bold text-12 line-height-3 mb-3 appear-animation"
                                        data-appear-animation="fadeInLeftShorterPlus" data-appear-animation-delay="500"
                                        data-appear-animation-duration="500ms" data-plugin-options="{'minWindowWidth': 0}">
                                        We can help you grow your business.
                                    </h1>
                                    <p class="text-4-5 text-color-dark font-weight-light mb-4" data-plugin-animated-letters
                                        data-plugin-options="{'startDelay': 600, 'minWindowWidth': 0, 'animationSpeed': 50}">
                                        Our digital solutions give you an edge over your competitors.</p>
                                    <a href="<?php echo e(route('contact')); ?>"
                                        class="btn btn-primary btn-modern font-weight-bold text-3 py-3 btn-px-5 mt-2 appear-animation"
                                        data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1000"
                                        data-plugin-options="{'minWindowWidth': 0}">GET STARTED NOW <i
                                            class="fas fa-arrow-right ml-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="owl-nav">
                <button type="button" role="presentation" class="owl-prev"></button>
                <button type="button" role="presentation" class="owl-next"></button>
            </div>
        </div>

        <div class="container container-lg-custom py-5 my-5">
            <div class="row justify-content-center">
                <div class="col-xl-8 text-center mb-4">
                    <h2 class="font-weight-bold text-8 mb-3 appear-animation" data-appear-animation="fadeIn">Who We Are
                    </h2>
                    <p class="line-height-9 text-4 appear-animation" data-appear-animation="fadeInUpShorter"
                        data-appear-animation-delay="200"><span class="opacity-7">Emarss Technologies is a Software
                            Company in Zimbabwe, and our focus is in offering quality and affordable digital
                            solutions - from mobile apps, websites and web apps.</span></p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-10 px-lg-5">
                    <div class="row">
                        <div class="col-md-6 mb-2 pb-2 px-2 appear-animation" data-appear-animation="fadeInRightShorter">
                            <span
                                class="thumb-info thumb-info-no-borders thumb-info-no-borders-rounded thumb-info-centered-info thumb-info-no-zoom thumb-info-slide-info-hover">
                                <span class="thumb-info-wrapper thumb-info-wrapper-no-opacity">
                                    <img src="img/office/our-office-9.jpg" class="img-fluid" alt="">
                                    <span class="thumb-info-title">
                                        <span class="thumb-info-slide-info-hover-1">
                                            <span class="thumb-info-inner text-4">Our Projects</span>
                                        </span>
                                        <span class="thumb-info-slide-info-hover-2">
                                            <span class="thumb-info-inner text-2">
                                                <a href="<?php echo e(route('projects')); ?>"
                                                    class="d-inline-flex align-items-center btn btn-light text-color-dark font-weight-bold px-4 btn-py-2 text-1 rounded">VIEW
                                                    OUR PROJECTS <i class="fa fa-arrow-right ml-2 pl-1 text-3"></i></a>
                                            </span>
                                        </span>
                                    </span>
                                </span>
                            </span>
                        </div>
                        <div class="col-md-6 mb-2 pb-2 px-2 appear-animation" data-appear-animation="fadeInLeftShorter">
                            <span
                                class="thumb-info thumb-info-no-borders thumb-info-no-borders-rounded thumb-info-centered-info thumb-info-no-zoom thumb-info-slide-info-hover">
                                <span class="thumb-info-wrapper thumb-info-wrapper-no-opacity">
                                    <img src="img/office/our-office-10.jpg" class="img-fluid" alt="">
                                    <span class="thumb-info-title">
                                        <span class="thumb-info-slide-info-hover-1">
                                            <span class="thumb-info-inner text-4">Our Services</span>
                                        </span>
                                        <span class="thumb-info-slide-info-hover-2">
                                            <span class="thumb-info-inner text-2">
                                                <a href="<?php echo e(route('services')); ?>"
                                                    class="d-inline-flex align-items-center btn btn-light text-color-dark font-weight-bold px-4 btn-py-2 text-1 rounded">VIEW
                                                    OUR SERVICES <i class="fa fa-arrow-right ml-2 pl-1 text-3"></i></a>
                                            </span>
                                        </span>
                                    </span>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <section class="section section-no-border section-height-4 mb-0">
            <div class="container">
                <div class="row justify-content-center text-center">
                    <div class="col-md-4 appear-animation" data-appear-animation="fadeInLeftBig">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Mobile Apps</h4>
                        <p class="px-lg-4 mb-0">
                            We are experts in mobile app development for both platforms - Android and iOS.
                        </p>
                    </div>
                    <div class="col-md-4 mb-2 appear-animation" data-appear-animation="fadeIn">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Web Apps</h4>
                        <p class="px-lg-4 mb-0">
                            We also develop business software that run over the browser. known as Web Apps.
                        </p>
                    </div>
                    <div class="col-md-4 appear-animation" data-appear-animation="fadeInRightBig">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Creative Websites</h4>
                        <p class="px-lg-4 mb-0">
                            Also, we develop creative, professional websites for companies and individuals.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-no-border section-height-3 bg-color-primary my-0">
            <div class="container">
                <div class="row counters counters-sm text-light">
                    <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0 appear-animation" data-appear-animation="fadeInLeftShorter">
                        <div class="counter">
                            <strong data-to="25" data-append="+">0</strong>
                            <label class="text-light opacity-6 font-weight-normal pt-1">Happy Clients</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0 appear-animation" data-appear-animation="fadeInDownShorter">
                        <div class="counter">
                            <strong data-to="6" data-append="+">0</strong>
                            <label class="text-light opacity-6 font-weight-normal pt-1">Active Projects</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mb-4 mb-sm-0 appear-animation" data-appear-animation="fadeInUpShorter">
                        <div class="counter">
                            <strong data-to="31">0</strong>
                            <label class="text-light opacity-6 font-weight-normal pt-1">Completed Projects</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 appear-animation" data-appear-animation="fadeInRightShorter">
                        <div class="counter">
                            <strong data-to="5" data-append="+">0</strong>
                            <label class="text-light opacity-6 font-weight-normal pt-1">Upcoming Projects</label>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="container my-5">
            <div class="row py-5">
                <div class="col">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="featured-boxes featured-boxes-modern-style-1">
                                <div class="featured-box overlay overlay-show overlay-op-9 border-radius border-0">
                                    <div class="featured-box-background"
                                        style="background-image: url(img/digital.png); background-size: cover; background-position: center;">
                                    </div>
                                    <div class="box-content px-lg-4 px-xl-5 py-lg-5">
                                        <div class="py-5 my-4">
                                            <a class="text-decoration-none lightbox" href="https://www.youtube.com/watch?v=l0dy6z8uWoU"
                                                data-plugin-options="{'type':'iframe'}">
                                                <img class="icon-animated" width="60"
                                                    src="vendor/linea-icons/linea-music/icons/play-button.svg" alt=""
                                                    data-icon
                                                    data-plugin-options="{'color': '#FFF', 'animated': true, 'delay': 600, 'strokeBased': true}" />
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 text-center text-lg-left">
                            <h4 class="text-6 font-weight-bold line-height-5 mt-4 mt-lg-0">Digitalisation is at the core of
                                our existance.</h4>
                            <p>All our services and projects were carefully selected and designed to help bring your
                                business on the map digitally in the <b>new normal</b>.</p>
                            <a href="<?php echo e(route('services')); ?>"
                                class="d-inline-flex align-items-center btn btn-dark text-color-light font-weight-bold px-4 btn-py-2 text-1 rounded">VIEW
                                OUR SERVICES <i class="fa fa-arrow-right ml-2 pl-1 text-3"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md ">
        <div class="container-fluid">
            <div class="row align-items-center">

                <div class="col">
                    <div class="row">
                        <div class="col-md-12 align-self-center p-static order-2 text-center">
                            <div class="overflow-hidden pb-2">
                                <h1 class="text-dark font-weight-bold text-9 appear-animation"
                                    data-appear-animation="maskUp" data-appear-animation-delay="100">PROJECTS</h2>
                            </div>
                        </div>
                        <div class="col-md-12 align-self-center order-1">
                            <ul class="breadcrumb d-block text-center appear-animation" data-appear-animation="fadeIn"
                                data-appear-animation-delay="300">
                                <li class="active">SOME OF OUR</li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <div class="container py-2">
        <div class="mt-1">
            <div class="row portfolio-list sort-destination">
                <div class="col-lg-12 mb-4 apps">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="portfolio-item">
                                    <a href="<?php echo e(route('projects.show', $project->slug)); ?>">
                                        <span
                                            class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation"
                                            data-appear-animation="fadeIn" data-appear-animation-delay="100">
                                            <span class="thumb-info-wrapper border-radius-0">
                                                <img src="<?php echo e($project->thumbnail()); ?>" class="img-fluid border-radius-0"
                                                    alt="">
                                                <span class="thumb-info-action">
                                                    <span class="thumb-info-action-icon bg-dark opacity-8"><i
                                                            class="fas fa-plus"></i></span>
                                                </span>
                                            </span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6">

                                <div class="overflow-hidden">
                                    <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="btn-link">
                                        <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation"
                                            data-appear-animation="maskUp" data-appear-animation-delay="600">
                                            <?php echo e($project->title); ?>

                                        </h2>
                                    </a>
                                </div>

                                <p class="appear-animation" data-appear-animation="fadeInUpShorter"
                                    data-appear-animation-delay="800"><?php echo e($project->except(250)); ?> </p>

                                <ul class="list list-icons list-primary list-borders text-2 appear-animation"
                                    data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                    <li><i class="fas fa-caret-right left-10"></i> <strong
                                            class="text-color-primary">Project URL:</strong> <a href="<?php echo e($project->url); ?>"
                                            class="btn-link"><?php echo e($project->url); ?></a></li>
                                    <li><i class="fas fa-caret-right left-10"></i> <strong
                                            class="text-color-primary">Date:</strong> <?php echo e($project->date->format('M, Y')); ?>

                                    </li>
                                    <li><i class="fas fa-caret-right left-10"></i> <strong
                                            class="text-color-primary">Skills:</strong>
                                        <?php $__currentLoopData = $project->skills(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span
                                                class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1"><?php echo e($skill); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($projects->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
        <div class="container">
            <div class="row">

                <div class="col-md-12 align-self-center p-static order-2 text-center">


                    <h1 class="text-dark font-weight-bold text-8">News & Updates</h1>
                    <span class="sub-title text-dark">Check out our Latest Blog Posts!</span>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-4">

        <div class="row">
            <div class="col">
                <div class="blog-posts">

                    <div class="row">

                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <article class="post post-medium border-0 pb-0 mb-5">
                                    <div class="post-image">
                                        <a href="<?php echo e(route('blog.show', $post->slug)); ?>">
                                            <img src="<?php echo e($post->thumbnail()); ?>"
                                                class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0"
                                                alt="<?php echo e($post->title); ?>" />
                                        </a>
                                    </div>

                                    <div class="post-content">

                                        <h2 class="font-weight-semibold text-4 line-height-6 mt-3 mb-2"><a
                                                href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e(Str::limit($post->title, 60)); ?></a>
                                        </h2>
                                        <p><?php echo e($post->except()); ?></p>

                                        <div class="post-meta">
                                            <span><i class="far fa-user"></i> By <a
                                                    href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a>
                                            </span>
                                            <span><i class="far fa-folder"></i>
                                                <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a
                                                        href="<?php echo e(route('search.category', $category->category)); ?>"><?php echo e(ucwords(str_replace('_', ' ', $category->category))); ?></a>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </span>
                                            <span class="d-block mt-2"><a href="<?php echo e(route('blog.show', $post->slug)); ?>"
                                                    class="btn btn-xs btn-light text-1 text-uppercase">Read
                                                    More</a></span>
                                        </div>

                                    </div>
                                </article>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/index.blade.php ENDPATH**/ ?>
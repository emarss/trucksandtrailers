<!-- Post Item Start -->
<div class="post--item post--layout-3">
    <div class="post--img">
        <a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>" alt=""></a>

        <div class="post--info">
            <ul class="nav meta">
                <li><a><?php echo e($post->user->name); ?></a></li>
                <li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
            </ul>

            <div class="title">
                <h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title, 50)); ?></a></h3>
            </div>
        </div>
    </div>
</div>
<!-- Post Item End --><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/post-format-two.blade.php ENDPATH**/ ?>
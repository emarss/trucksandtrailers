<?php $__env->startSection('content'); ?>

    <!-- Main Content Section Start -->
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <div class="col-md-12 ptop--30 pbottom--30">
                    <div class="post--items-title" data-ajax="tab">
                        <h2 class="h4">Photos Gallery</h2>
                    </div>

                    <div class="post--items post--items-1" data-ajax-content="outer">
                        <?php echo $__env->make('inc.photos-partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
                    </div>
                    <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--60 pbottom--30">
                        <?php echo e($photos->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lightgallery@1.8.2/dist/css/lightgallery.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/lightgallery@1.8.2/dist/js/lightgallery.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#lightgallery").lightGallery(); 
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/photos-gallery.blade.php ENDPATH**/ ?>
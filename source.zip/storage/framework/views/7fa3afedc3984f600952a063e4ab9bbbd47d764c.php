<div class="container">
    <?php if(Session::has('success')): ?>
        <div class="alert alert-info alert-dismissible" style="border-radius: 0; margin-top: 20px;">
            <a class="close" data-dismiss="alert">&times;</a>       
            Success: <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger alert-dismissible" style="border-radius: 0; margin-top: 20px;">
            <a class="close" data-dismiss="alert">&times;</a>       
            Fail: <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible" style="border-radius: 0; margin-top: 20px;">
            <a class="close" data-dismiss="alert">&times;</a>       
            Error: <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/messages.blade.php ENDPATH**/ ?>
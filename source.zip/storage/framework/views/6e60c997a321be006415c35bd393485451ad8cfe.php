<?php $__env->startSection('content'); ?>
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="post--items-title" data-ajax="tab">
                        <h2 class="h4">Documents</h2>
                    </div>
                </div>
               
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                    <div class="col-xs-4 mb-5">
                        <?php echo $__env->make('inc.document-format-one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12">
                    <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--60 pbottom--30">
                        <?php echo e($documents->links()); ?>

                    </div>
                </div>                
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/documents.blade.php ENDPATH**/ ?>
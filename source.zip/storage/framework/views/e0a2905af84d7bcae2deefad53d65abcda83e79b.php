<?php $__env->startSection('content'); ?>
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <div class="main--content col-md-12" data-sticky-content="true">
                    <div class="sticky-content-inner">
                        <div class="post--items post--items-2 pd--30-0">
                            <h2><?php echo e("Videos: ". ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <ul class="nav row AdjustRow">
                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-md-4 mb-5 pb-5 col-sm-12 col-xs-6 col-xss-12">
                                        <?php echo $__env->make("inc.video-format-one", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--30 pbottom--60">
                            <a href="<?php echo e(route('search.videos', $search)); ?>" class="btn btn-primary btn-lg">More Videos Results</a>
                        </div>
                    </div>


                    <div class="sticky-content-inner">
                        <div class="post--items post--items-2 pd--30-0">
                            <h2><?php echo e("Posts: ". ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <ul class="nav row AdjustRow">
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-md-4 mb-5 pb-5 col-sm-12 col-xs-6 col-xss-12">
                                        <?php echo $__env->make("inc.post-format-one", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--30 pbottom--60">
                            <a href="<?php echo e(route('search.posts', $search)); ?>" class="btn btn-primary btn-lg">More Posts Results</a>
                        </div>
                    </div>


                    <div class="sticky-content-inner">
                        <div class="post--items post--items-2 pd--30-0">
                            <h2><?php echo e("Photos: ". ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <ul class="nav row AdjustRow">
                                <?php echo $__env->make('inc.photos-partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </div>
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--30 pbottom--60">
                            <a href="<?php echo e(route('search.photos', $search)); ?>" class="btn btn-primary btn-lg">More Photos Results</a>
                        </div>
                    </div>


                    <div class="sticky-content-inner">
                        <div class="post--items post--items-2 pd--30-0">
                            <h2><?php echo e("Documents: ". ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <div class="row AdjustRow">
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-5 pb-5 col-sm-12 col-xs-6 col-xss-12">
                                        <?php echo $__env->make("inc.document-format-one", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--30 pbottom--60">
                            <a href="<?php echo e(route('search.documents', $search)); ?>" class="btn btn-primary btn-lg">More Documents Results</a>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/search.blade.php ENDPATH**/ ?>
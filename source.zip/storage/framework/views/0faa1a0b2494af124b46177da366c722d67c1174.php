<!-- Widget Start -->
<div class="widget">
    <!-- Search Widget Start -->
    <div class="search--widget">
        <form action="<?php echo e(route('blog.search')); ?>" method="get">
            <div class="input-group">
                <input type="search" name="search" placeholder="Search..." class="form-control" required>

                <div class="input-group-btn">
                    <button type="submit" class="btn-link"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
    </div>
    <!-- Search Widget End -->
</div><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/blog-search-sidebar.blade.php ENDPATH**/ ?>
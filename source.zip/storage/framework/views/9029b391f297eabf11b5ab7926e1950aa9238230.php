<?php $__env->startSection('content'); ?>
		<div class="main-content--section pbottom--30">
				<div class="container">
						<div class="main--content">
								<div class="post--items post--items-1 pd--30-0">
										<div class="row gutter--15">

												<div class="col-md-6">
														<!-- News Update Start -->
														<div class="post--item post--layout-1 post--title-larger">
																<?php if($newsUpdatePosts->count() > 0): ?>
																		<?php
																				$post = $newsUpdatePosts->first();
																				$category = $post->categories()->random();
																		?>

																		<div class="post--img">
																				<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>
																				
																				<a href="<?php echo e(route("blog.search", "news_update")); ?>" class="cat">NEWS UPDATE</a>
																				
																				<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="icon"><i class="fa fa-flash"></i></a>

																				<div class="post--info">
																						<ul class="nav meta">
																								<li><a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a></li>
																								<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																						</ul>

																						<div class="title">
																								<h2 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title)); ?></a></h2>
																						</div>
																				</div>
																		</div>
																<?php else: ?>
																		<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																<?php endif; ?>
														</div>
														<!-- Post Item End -->
												</div>


												<div class="col-md-6">
														<div class="row gutter--15">
																
																<?php $__empty_1 = true; $__currentLoopData = $analysisPosts->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysisPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
																		<div class="col-xs-6 col-xss-12">
																				<div class="post--item post--layout-1 post--title-large">
																						<div class="post--img">
																								
																								<a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="thumb"><img src="<?php echo e($analysisPost->thumbnail()); ?>"></a>
																								
																								<a href="<?php echo e(route("blog.search", "analysis")); ?>" class="cat">Analysis</a>
																								
																								<div class="post--info">
																										<ul class="nav meta">
																												<li><a><?php echo e($analysisPost->created_at->diffForHumans()); ?></a></li>
																										</ul>

																										<div class="title">
																												<h2 class="h4"><a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="btn-link"><?php echo e(Str::limit($analysisPost->title, 60)); ?></a></h2>
																										</div>

																								</div>
																						</div>
																				</div>
																		</div>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
																		<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																<?php endif; ?>



																<div class="col-sm-12 hidden-sm hidden-xs">
																		<!-- Post Item Start -->
																		<div class="post--item post--layout-1 post--title-larger">
																				<?php if($weeklyReportPosts->count() > 0): ?>
																						<?php 
																								$post = $weeklyReportPosts->first();
																						?>
																						<div class="post--img">
																								<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->longThumb()); ?>"></a>
																								
																								<a href="<?php echo e(route("blog.search", "weekly_report")); ?>" class="cat">Weekly Report</a>
																								
																								<div class="post--info">
																										<ul class="nav meta">
																												<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																										</ul>

																										<div class="title">
																												<h2 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title)); ?></a></h2>
																										</div>
																								</div>
																						<?php else: ?>
																								<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																						<?php endif; ?>
																				</div>
																		</div>
																		<!-- Post Item End -->
																</div>
														</div>
												</div>
										</div>
								</div>
						</div>

						<?php if($defenders->count()): ?>
							    <!-- Counter Section Start -->
						    <div class="counter--section">
						        <div class="row just gutter--0 odd bg--color-1">
						            <div class=" text-center">
						                <h1 class="">Human Rights Cases</h1>
						            </div><hr>
						            <?php $__currentLoopData = $defenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $defender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							            <div class="col-md-3 col-xs-6 col-xxs-12">
							                <div class="p-lg-5 p-3 <?php if($loop->even): ?> even <?php else: ?> odd <?php endif; ?> bg--color-1">
							                	<h4><b class="text-uppercase">Status: <?php echo e($defender->status); ?></b></h4>
							                	<img  src="<?php echo e($defender->thumbnail()); ?>" alt="" class="img-thumbnail">
							                	<h4><?php echo e($defender->name); ?></h4>
							                	<p><small><?php echo e($defender->date->format("d M, Y")); ?></small> </p>
							                    <p><?php echo e($defender->description); ?></p>
							                    <p><b>Violations:</b> <?php echo e($defender->violations); ?></p>
							                    <p><b>Location:</b> <?php echo e($defender->location); ?></p>
							                </div>
							                <!-- Counter Item End -->
							            </div>
						            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        </div>
						    </div>
						    <!-- Counter Section End -->
						<?php endif; ?>

						<div class="row">
								<div class="main--content col-md-8 col-sm-7" data-sticky-content="true">
										<div class="sticky-content-inner">
												<div class="row">
														<div class="col-md-6 ptop--30 pbottom--30">
																<div class="post--items-title" data-ajax="tab">
																		<h2 class="h4">News Updates</h2>

																		<div class="nav">
																				<a href="<?php echo e(route('blog')); ?>" class="prev btn-link" data-ajax-action="load_prev_world_news_posts">
																						<i class="fa fa-expand"></i>
																				</a>
																		</div>
																</div>

																<div class="post--items post--items-2" data-ajax-content="outer">
																		<ul class="nav row gutter--15" data-ajax-content="inner">
																				<li class="col-xs-12">
																						
																						<div class="post--item post--layout-1">
																								<?php if($newsUpdatePosts->count() > 1): ?>
																										<?php 
																												$post = $newsUpdatePosts->skip(1)->first();
																										?>

																										<div class="post--img">
																												<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>

																												<div class="post--info">
																														<ul class="nav meta">
																																<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																														</ul>

																														<div class="title">
																																<h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title)); ?></a></h3>
																														</div>
																												</div>
																										<?php else: ?>
																												<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																										<?php endif; ?>                                                        
																								</div>
																						</div>

																				</li>

																				<li class="col-xs-12">
																						<hr class="divider">
																				</li>

																				<li class="col-xs-6">
																						<!-- Post Item Start -->
																						<div class="post--item post--layout-2">
																								<?php if($newsUpdatePosts->count() > 2): ?>
																										<?php 
																												$post = $newsUpdatePosts->skip(2)->first();
																										?>
																										<div class="post--img">
																												<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>

																												<div class="post--info">
																														<ul class="nav meta">
																																<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																														</ul>

																														<div class="title">
																																<h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title, 50)); ?></a></h3>
																														</div>
																												</div>
																										<?php else: ?>
																												<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																										<?php endif; ?>
																								</div>
																						</div>
																				</li>
																				<li class="col-xs-6">
																						<div class="post--item post--layout-2">
																								<?php if($newsUpdatePosts->count() > 3): ?>
																										<?php 
																												$post = $newsUpdatePosts->skip(3)->first();
																										?>

																										<div class="post--img">
																												<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>

																												<div class="post--info">
																														<ul class="nav meta">
																																<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																														</ul>

																														<div class="title">
																																<h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title, 50)); ?></a></h3>
																														</div>
																												</div>
																										<?php else: ?>
																												<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																										<?php endif; ?>          
																								</div>
																						</div>
																				</li>

																				<li class="col-xs-12">
																						<hr class="divider">
																				</li>
																		</ul>
																</div>
														</div>



														<div class="col-md-6 ptop--30 pbottom--30">
																<div class="post--items-title" data-ajax="tab">
																		<h2 class="h4">Weekly Reports</h2>

																		<div class="nav">
																				<a href="<?php echo e(route('blog')); ?>" class="prev btn-link" data-ajax-action="load_prev_technology_posts">
																						<i class="fa fa-expand"></i>
																				</a>
																		</div>
																</div>

																<div class="post--items post--items-3" data-ajax-content="outer">
																		<ul class="nav" data-ajax-content="inner">
																				<?php if($weeklyReportPosts->count() > 1): ?>
																						<?php $__currentLoopData = $weeklyReportPosts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																								<li>
																										<div class="post--item post--layout-3">
																												<div class="post--img">
																														<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>

																														<div class="post--info">
																																<ul class="nav meta">
																																		<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																																</ul>

																																<div class="title">
																																		<h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e(Str::limit($post->title, 60)); ?></a></h3>
																																</div>
																														</div>
																												</div>
																										</div>
																								</li>
																						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				<?php else: ?>
																						<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																				<?php endif; ?>
																		</ul>
																</div>
														</div>


														<div class="col-md-12 ptop--60 pbottom--30">
																<div class="post--items-title" data-ajax="tab">
																		<h2 class="h4">Analysis</h2>
																		<div class="nav">
																				<a href="<?php echo e(route('blog')); ?>" class="prev btn-link" data-ajax-action="load_prev_finance_posts">
																						<i class="fa fa-expand"></i>
																				</a>
																		</div>
																</div>

																<div class="post--items post--items-2" data-ajax-content="outer">
																		<ul class="nav row" data-ajax-content="inner">
																				<li class="col-md-6">
																						<div class="post--item post--layout-2">
																								<?php if($analysisPosts->count() > 2): ?>
																										<?php 
																												$post = $analysisPosts->skip(2)->first();
																										?>
																										<div class="post--img">
																												
																												<a href="<?php echo e(route('blog.show', $post->id)); ?>" class="thumb"><img src="<?php echo e($post->thumbnail()); ?>"></a>
																												
																												<a href="<?php echo e(route('blog.search', 'analysis')); ?>" class="cat">Analysis</a>

																												<div class="post--info">
																														<ul class="nav meta">
																																<li><a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a></li>
																																<li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
																														</ul>

																														<div class="title">
																																<h3 class="h4"><a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn-link"><?php echo e($post->title); ?></a></h3>
																														</div>
																												</div>
																										</div>
																								<?php else: ?>
																										<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																								<?php endif; ?>
																						</div>
																				</li>


																				<li class="col-md-6">
																						<ul class="nav row">
																								<li class="col-xs-12 hidden-md hidden-lg">
																										<hr class="divider">
																								</li>

																								<?php if($analysisPosts->count() > 3): ?>
																										<?php $__currentLoopData = $analysisPosts->slice(3,2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $$analysisPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																												<li class="col-xs-6">
																														<div class="post--item post--layout-2">
																																<div class="post--img">
																																		<a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="thumb"><img src="<?php echo e($analysisPost->thumbnail()); ?>"></a>

																																		<div class="post--info">
																																				<ul class="nav meta">
																																						<li><a><?php echo e($analysisPost->created_at->diffForHumans()); ?></a></li>
																																				</ul>

																																				<div class="title">
																																						<h3 class="h4"><a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="btn-link"><?php echo e(Str::limit($analysisPost->title, 40)); ?></a></h3>
																																				</div>
																																		</div>
																																</div>
																														</div>
																												</li>
																										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																								<?php else: ?>
																										<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																								<?php endif; ?>

																								<li class="col-xs-12">
																										<hr class="divider">
																								</li>

																								<?php if($analysisPosts->count() > 5): ?>
																										<?php $__currentLoopData = $analysisPosts->skip(5)->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysisPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																												<li class="col-xs-6">
																														<div class="post--item post--layout-2">
																																<div class="post--img">
																																		<a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="thumb"><img src="<?php echo e($analysisPost->thumbnail()); ?>"></a>

																																		<div class="post--info">
																																				<ul class="nav meta">
																																						<li><a><?php echo e($analysisPost->created_at->diffForHumans()); ?></a></li>
																																				</ul>

																																				<div class="title">
																																						<h3 class="h4"><a href="<?php echo e(route('blog.show', $analysisPost->id)); ?>" class="btn-link"><?php echo e(Str::limit($analysisPost->title, 40)); ?></a></h3>
																																				</div>
																																		</div>
																																</div>
																														</div>
																												</li>
																										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																								<?php endif; ?>
																						</ul>
																				</li>
																		</ul>
																</div>
														</div>
												</div>
										</div>
								</div>
								<!-- Main Content End -->

								<div class="main--sidebar col-md-4 col-sm-5 ptop--30 pbottom--30" data-sticky-content="true">
										<div class="">
												<?php echo $__env->make('inc.socials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

												<?php echo $__env->make('inc.newsletter-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
										</div>
								</div>
						</div>

						<div class="main--content pd--30-0">
								<div class="post--items-title" data-ajax="tab">
										<h2 class="h4">Videos Gallery</h2>

										<div class="nav">
												<a href="<?php echo e(route('videos-gallery')); ?>" class="prev btn-link">
														<i class="fa fa-expand"></i>
												</a>
										</div>
								</div>

								<div class="post--items post--items-4" data-ajax-content="outer">
										<ul class="nav row" data-ajax-content="inner">
												<li class="col-md-7">
														<div class="post--item ppost--single post--type-video post--title-large">
																<?php if($videos->count() > 0): ?>
																		<div class="post--img">
																				<div class="embed-responsive embed-responsive-16by9">
																						<iframe class="embed-responsive-item" src="<?php echo e($videos->first()->getPath()); ?>" allowfullscreen></iframe>
																				</div>

																				<div class="post--info">
																						<ul class="nav meta">
																								<li><a><?php echo e($videos->first()->created_at->diffForHumans()); ?></a></li>
																						</ul>

																						<div class="title">
																								<h2 class="h4"><a href="<?php echo e(route('videos-gallery.show', $videos->first()->id)); ?>" class="btn-link"><?php echo $videos->first()->description; ?></a></h2>
																						</div>
																				</div>
																		</div>
																<?php else: ?>
																		<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																<?php endif; ?>
														</div>

														<hr class="divider hidden-md hidden-lg">
												</li>

												<li class="col-md-5">
														<ul class="nav">
																<?php if($videos->count() > 1): ?>
																		<?php $__currentLoopData = $videos->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<li>
																						<div class="post--item post--type-video post--layout-3">
																								<div class="post--img">
																										<a href="<?php echo e(route('videos-gallery.show', $video->id)); ?>" class="thumb"><img src="<?php echo e($video->thumbnail()); ?>"></a>

																										<div class="post--info">
																												<ul class="nav meta">
																														<li><a><?php echo e($video->created_at->diffForHumans()); ?></a></li>
																												</ul>

																												<div class="title">
																													<h3 class="h4"><a href="<?php echo e(route('videos-gallery.show', $video->id)); ?>" class="btn-link"><?php echo Str::limit($video->description, 100); ?></a></h3>
																												</div>
																										</div>

																								</div>
																						</div>
																				</li>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																<?php else: ?>
																		<div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
																<?php endif; ?>
														</ul>
												</li>
										</ul>
								</div>
						</div>


						<div class="row">
								<div class="main--content col-md-12" data-sticky-content="true">
										<div class="sticky-content-inner">
												<div class="row">
														<div class="col-md-12 ptop--30 pbottom--30">
																<div class="post--items-title" data-ajax="tab">
																		<h2 class="h4">Photos Gallery</h2>
																		<div class="nav">
																				<a href="<?php echo e(route('photos-gallery')); ?>" class="prev btn-link" data-ajax-action="load_prev_photo_gallery_posts">
																						<i class="fa fa-expand"></i>
																				</a>
																		</div>
																</div>

																<div class="post--items post--items-1" data-ajax-content="outer">
																		<?php echo $__env->make('inc.photos-partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
																</div>
														</div>
												</div>
										</div>
								</div>
						</div>
				</div>
		</div>
		<!-- Main Content Section End -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lightgallery@1.8.2/dist/css/lightgallery.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
		<script src="https://cdn.jsdelivr.net/npm/lightgallery@1.8.2/dist/js/lightgallery.min.js"></script>
		<script>
				$(document).ready(function() {
						$("#lightgallery").lightGallery(); 
				});
		</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/index.blade.php ENDPATH**/ ?>
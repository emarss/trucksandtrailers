<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($pageTitle); ?>

                <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-primary btn-sm float-right">Edit
                    Post</a>
            </h4>
        </div>
        <div class="card-body">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><b>Title</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php echo e($post->title); ?>

                    </p>
                </div>
                <div class="card-header">
                    <h4 class="card-title"><b>Tags</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php $__currentLoopData = $post->tags(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-primary py-1"><?php echo e(ucfirst($tag)); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
                <div class="card-header">
                    <h4 class="card-title"><b>Categories</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="badge badge-primary py-1"><?php echo e(ucwords(str_replace('_', ' ', $category->category))); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
                <div class="card-header">
                    <h4 class="card-title"><b>Body</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php echo $post->body; ?>

                    </p>
                </div>
                <div class="card-header">
                    <h4 class="card-title"><b>Thumbnail</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <img src="<?php echo e($post->featuredImage()); ?>" alt="<?php echo e($post->title); ?>" height="200">
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Created By</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($post->user->name); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Created At</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($post->created_at->diffForHumans()); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Last Updated</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($post->updated_at->diffForHumans()); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/admin/posts/show.blade.php ENDPATH**/ ?>
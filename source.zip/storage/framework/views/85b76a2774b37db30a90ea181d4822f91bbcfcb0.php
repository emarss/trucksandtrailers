<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div role="main" class="main">
        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">


                        <h1 class="text-dark font-weight-bold text-8">Our Services</h1>
                        <span class="sub-title text-dark">What We Offer!</span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="active">Services</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="section bg-color-white section-no-border section-height-4 mb-0">
            <div class="container">
                <div class="row justify-content-center text-center">
                    <div class="col-md-4 appear-animation" data-appear-animation="fadeInLeftBig">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Mobile Apps</h4>
                        <p class="px-lg-4 mb-0">
                            We are experts in mobile app development for both platforms - Android and iOS.
                        </p>
                    </div>
                    <div class="col-md-4 mb-2 appear-animation" data-appear-animation="fadeIn">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Web Apps</h4>
                        <p class="px-lg-4 mb-0">
                            We also develop business software that run over the browser. known as Web Apps.
                        </p>
                    </div>
                    <div class="col-md-4 appear-animation" data-appear-animation="fadeInRightBig">
                        <h4 class="font-weight-bold mb-2 mt-4 mt-md-0">Creative Websites</h4>
                        <p class="px-lg-4 mb-0">
                            Also, we develop creative, professional websites for companies and individuals.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="section bg-color-primary section-height-3 border-0 mt-4 mb-0">
            <div class="container">

                <div class="row">
                    <div class="col-md-10 py-3 mx-md-auto">
                        <div class="row pt-2 clearfix">
                            <div class="col-lg-6">
                                <div class="feature-box feature-box-style-2 reverse appear-animation" data-appear-animation="fadeInRightShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-globe-alt icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <h4 class="mb-2 text-5 text-color-light">Innovative</h4>
                                        <p class="mb-4 text-color-light opacity-6">Our team, made up of engineers and business, thrives to find solutions, even to the the most daring problems your business might be facing.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-layers icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <h4 class="mb-2 text-5 text-color-light">Results Driven</h4>
                                        <p class="mb-4 text-color-light opacity-6">We do not start a project without setting goals and objectives, and as we proceed, we constantly re-align our efforts to the set objectives.  </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-lg-6">
                                <div class="feature-box feature-box-style-2 reverse appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">
                                    <div class="feature-box-icon">
                                        <i class="icon-screen-smartphone icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <h4 class="mb-2 text-5 text-color-light">Modern UX Designs</h4>
                                        <p class="mb-4 text-color-light opacity-6">UI/UX design trends appear every year, as is the way with trends. We strive to give our customers the best user experience at all time.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200">
                                    <div class="feature-box-icon">
                                        <i class="icon-wallet icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <h4 class="mb-2 text-5 text-color-light">Affordable Solutions</h4>
                                        <p class="mb-4 text-color-light opacity-6">Our services and products are targeted torwards small to medium enterprises, therefore, we set our prices with our customers in mind.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </section>

        <div class="container">
            <div class="row justify-content-center pt-4 mt-5 mb-5">
                <div class="col-lg-8 text-center">
                    <div class="overflow-hidden mb-3">
                        <h2 class="font-weight-bold mb-0 appear-animation" data-appear-animation="maskUp">Learn more about our process</h2>
                    </div>
                    <div class="overflow-hidden mb-3">
                        <p class="lead mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">We understand that every project is unique and it comes with special needs and requirements, therefore before we can start working on your project, we do our best to thoroughly understand your project from the inside out. </p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center pb-5">

                <div class="col-md-7 col-lg-4 mb-5 mb-lg-0">
                    <div class="circular-bar mb-lg-5 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="600">
                        <div class="circular-bar-chart" data-percent="25" data-plugin-options="{'barColor': '#0088cc'}">
                            <strong class="mt-2 text-color-primary">25%</strong>
                        </div>
                    </div>
                    <div class="col text-center appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="900">
                        <h4 class="font-weight-bold">Meeting</h4>
                        <p class="px-3">We take meetings with our clients very seriously. We set aside enough time to meet our customers, whether physically or virtually before we commence every project.</p>
                    </div>
                </div>

                <div class="col-md-7 col-lg-4 mb-5 mb-lg-0">
                    <div class="circular-bar mb-lg-5 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="400">
                        <div class="circular-bar-chart" data-percent="75" data-plugin-options="{'barColor': '#0088cc'}">
                            <strong class="mt-2 text-color-primary">75%</strong>
                        </div>
                    </div>
                    <div class="col text-center appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="900">
                        <h4 class="font-weight-bold">Execute</h4>
                        <p class="px-3">Once we have met our customers, all relevant stakeholders, and clearly understood the requirements of the project, we then start designing and developing the project.</p>
                    </div>
                </div>

                <div class="col-md-7 col-lg-4">
                    <div class="circular-bar mb-lg-5 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600">
                        <div class="circular-bar-chart" data-percent="100" data-plugin-options="{'barColor': '#0088cc'}">
                            <strong class="mt-2 text-color-primary">100%</strong>
                        </div>
                    </div>
                    <div class="col text-center appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="900">
                        <h4 class="font-weight-bold">Delivery</h4>
                        <p class="px-3">After developing the project, we thoroughly test it in-house to ensure that it was properly implemented and it meets the needs of our clients, and then we deliver.</p>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/services.blade.php ENDPATH**/ ?>
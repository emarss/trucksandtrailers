
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
      <div class="card-header">
        	<h4 class="card-title">
          	<?php echo e($pageTitle); ?>

        	</h4>
      </div>
      <div class="card-body">
        <dl>
            <dt>Name</dt>
            <dd class="ml-3"><?php echo e($feedback->name); ?></dd>

            <dt>Email</dt>
            <dd class="ml-3"><a href="mailto:<?php echo e($feedback->email); ?>"><?php echo e($feedback->email); ?></a></dd>

            <?php if($feedback->website != ""): ?>
              <dt>Email</dt>
              <dd class="ml-3"><a href="<?php echo e($feedback->website); ?>"><?php echo e($feedback->website); ?></a></dd>
            <?php endif; ?>

            <dt>Message</dt>
            <dd class="ml-3"><?php echo e($feedback->message); ?></dd>
        </dl><hr>
        <button onclick="confirmDelete('<?php echo e(route('admin.feedback.destroy', $feedback->id)); ?>')" class="btn btn-sm btn-danger">Delete</button>

      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/feedback/show.blade.php ENDPATH**/ ?>
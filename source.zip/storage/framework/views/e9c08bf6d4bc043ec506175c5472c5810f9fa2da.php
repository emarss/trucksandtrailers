<!-- Footer Section Start -->
<footer class="footer--section ptop--30">
    <!-- Footer Widgets Start -->
    <div class="footer--widgets pd--30-0 bg--color-2">
        <div class="container">
            <div class="row AdjustRow">
                <div class="col-md-4 col-xs-12 ptop--30 pbottom--30">
                    <!-- Widget Start -->
                    <div class="widget">
                        <div class="widget--title">
                            <h2 class="h4">Our Focus</h2>
                        </div>

                        <!-- About Widget Start -->
                        <div class="about--widget">
                            <div class="content">
                                <p>Political Rights, Access to Information, Freedom of expression and association, Citizenship, Community / Customary Land Rights, Corruption, Criminal Justice, Environmental Justice, Governance, Land and Natural Resources </p>
                            </div>

                            <div class="action">
                                <a href="<?php echo e(route('about')); ?>" class="btn-link">Read More<i class="fa flm fa-angle-double-right"></i></a>
                            </div>

                            <ul class="nav">
                                <li>
                                    <i class="fa fa-map"></i>
                                    <span>7 Capri Rd, Highlands, Harare, Zimbabwe</span>
                                </li>
                                <li>
                                    <i class="fa fa-envelope-o"></i>
                                    <a href="mailto:contact@zhrmp.co.zw">contact@zhrmp.co.zw</a>
                                </li>
                                <li>
                                    <i class="fa fa-phone"></i>
                                    <a href="tel:+263776826851">+263 77 682 6851</a>
                                </li>
                            </ul>
                        </div>
                        <!-- About Widget End -->
                    </div>
                    <!-- Widget End -->
                </div>

                <div class="col-md-4 col-xs-12 ptop--30 pbottom--30">
                    <!-- Widget Start -->
                    <div class="widget">
                        <div class="widget--title">
                            <h2 class="h4">Recent Posts</h2>
                        </div>

                        <!-- Links Widget Start -->
                        <div class="links--widget">
                            <ul class="nav">
                                <?php $__currentLoopData = \Helper::getRecentPosts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route("blog.show", $post->id)); ?>" class="fa-angle-right"><?php echo e(Str::limit($post->title, 50)); ?>. </a>
                                        <small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?>.</small>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Links Widget End -->
                    </div>
                    <!-- Widget End -->
                </div>

                <div class="col-md-4 col-xs-12 ptop--30 pbottom--30">
                    <!-- Widget Start -->
                    <div class="widget">
                        <div class="widget--title">
                            <h2 class="h4">Newsletter</h2>

                            <i class="icon fa fa-emvelope"></i>
                        </div>

                        <!-- Links Widget Start -->
                        <div class="links--widget">

                            <!-- Subscribe Widget Start -->
                            <div class="subscribe--widget">
                                <div class="content">
                                    <p>Subscribe to our newsletter to get  latest news, popular news and exclusive updates.</p>
                                </div>

                                <form action="<?php echo e(route('newsletter')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group">
                                        <input value="<?php echo e(old('email')); ?>" type="email" name="email" placeholder="E-mail address" class="form-control"  required>
                                        <div class="input-group-btn">
                                            <button type="submit" class="btn btn-lg btn-default active"><i class="fa fa-paper-plane-o"></i></button>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="text-danger my-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </form>
                            </div>
                            <!-- Subscribe Widget End -->
                        </div>
                        <!-- Links Widget End -->
                    </div>
                    <!-- Widget End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Widgets End -->

    <!-- Footer Copyright Start -->
    <div class="footer--copyright bg--color-3">
        <div class="social--bg bg--color-1"></div>

        <div class="container">
            <p class="text float--left">&copy; <?php echo e(now()->format('Y')); ?> <a href="/">ZHRMP</a>. All Rights Reserved.</p>

            <ul class="nav social float--right">
                <li><a href="https://www.facebook.com/Zimbabwe-Human-Rights-Monitors-Platform-115556003550202"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://twitter.com/HumanDefendes"><i class="fa fa-twitter"></i></a></li>
                <li><a href="https://www.youtube.com/channel/UCtnawD23IxgW-jqZFjSpTbg"><i class="fa fa-youtube-play"></i></a></li>
            </ul>

            <ul class="nav links float--right">
                <li><a href="<?php echo e(route('cookies')); ?>">Cookies Policy</a></li>
                <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                <li><a href="<?php echo e(route('terms')); ?>">Terms of Use</a></li>
            </ul>
        </div>
    </div>
    <!-- Footer Copyright End -->
</footer>
<!-- Footer Section End -->
<?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/inc/footer.blade.php ENDPATH**/ ?>
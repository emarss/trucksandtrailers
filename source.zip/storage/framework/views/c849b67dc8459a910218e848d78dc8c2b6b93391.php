<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- ==== Document Meta ==== -->
<meta name="author" content="Rufaro Sithole">
<meta name="keywords" content="Zimbabwe Human Rights Monintors Platform. Advocating for a Lawful Zimbabwe. Rufaro Sithole">
<meta name="description" content="Zimbabwe Human Rights Monintors Platform. Advocating for a Lawful Zimbabwe.">

<!-- ==== Favicons ==== -->
<link rel="icon" href="favicon.png" type="image/png">

<!-- ==== Google Font ==== -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700">

<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">


<meta property='og:locale' content='en_US'>
<meta property='og:site_name' content='Zimbabwe Human Rights Monintors Platform'>
<meta property='og:url' content="<?php echo e(Request::url()); ?>">

<?php if(Request::is('videos-gallery/*')): ?>
	<meta property='og:type' content='article'>
	<?php if(isset($current)): ?>
		<meta property='og:title' content="Video - <?php echo $current->description; ?>">
		<meta property='og:image' content="<?php echo e($current->thumbnail()); ?>">
		<meta property='og:description' content="<?php echo $current->description; ?>">
	<?php endif; ?>
<?php elseif(Request::is("blog/*")): ?>
	<meta property='og:type' content='article'>
	<?php if(isset($current)): ?>
		<meta property='og:title' content="<?php echo e($current->title); ?>">
		<meta property='og:image' content="<?php echo e($current->featuredImage()); ?>">
		<meta property='og:description' content="<?php echo $current->except(); ?>">
	<?php endif; ?>
<?php else: ?>
	<meta property='og:type' content='website'>
	<meta property='og:title' content='Zimbabwe Human Rights Monintors Platform'>
	<meta property='og:image' content="<?php echo e(asset('img/logo_long.png')); ?>">
	<meta property='og:description' content='Zimbabwe Human Rights Monintors Platform. Advocating for a Lawful Zimbabwe.'>

<?php endif; ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/head.blade.php ENDPATH**/ ?>
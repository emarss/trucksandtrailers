<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('content'); ?>
<div class="sub_header_in">
    <div class="container">
        <h1>Add Listing</h1>
    </div>
</div>


<main>
    <div class="container margin_60_35">
        <div class="row justify-content-center">

            <div class="col-xl-8 col-lg-8 pr-xl-5">
                <div class="main_title_3">
                    <span></span>
                    <h2>Submit Listing</h2>
                    <p>Submit a product or service and our team will approve it for listing</p>
                </div>
                <form method="post" action="<?php echo e(route('save_listing')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h5 class="h5">Basic Info</h5>
                    <hr>
                    <div class="form-group">
                        <label class="form-control-label" for="name">Name</label>
                        <input value="<?php echo e(old('name')); ?>" required="" type="text" name="name" class="form-control"
                            placeholder="Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label" for="formGroupExampleInput2">Description</label>
                        <textarea name="description" placeholder="Listing description" class="form-control"><?php echo old('description'); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="condition">Condition</label>
                            <select class="form-control condition" required name="condition">
                                <option value="">Select condition</option>
                                <option <?php echo e(old('condition') == 'new' ? 'selected' : ''); ?> value="new">New</option>
                                <option <?php echo e(old('condition') == 'preowned' ? 'selected' : ''); ?> value="preowned">Preowned
                                </option>
                            </select>
                            <?php $__errorArgs = ['condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Category </label>
                            <select class="form-control category" name="category" required="">
                                <option value="">Select category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('category') == $category->id ? 'selected' : ''); ?>

                                        value="<?php echo e($category->id); ?>"><?php echo e(ucwords($category->category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <h5 class="h5 mt-4">Contact Info</h5>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="cell_number">Cell Number</label>
                            <input value="<?php echo e(old('cell_number')); ?>" required="" type="text" name="cell_number"
                                class="form-control" placeholder="Enter mobile number">
                            <?php $__errorArgs = ['cell_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="whatsapp_number">WhatsApp Number
                                <i>(Optional)</i></label>
                            <input value="<?php echo e(old('whatsapp_number')); ?>" required="" type="text" name="whatsapp_number"
                                class="form-control" placeholder="Enter Whatsapp Number">
                            <?php $__errorArgs = ['whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="location">Location
                                </label>
                            <input value="<?php echo e(old('location')); ?>" required="" type="text" name="location"
                                class="form-control" placeholder="Enter Location">
                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="email">Email Address<i>(Optional)</i></label>
                            <input value="<?php echo e(old('email')); ?>" required="" type="email" name="email" class="form-control"
                                placeholder="Enter Email Address">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <h5 class="h5 mt-4">Pricing</h5>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="price">Price</label>
                            <input value="<?php echo e(old('price')); ?>" required="" type="number" step="0.01" name="price"
                                class="form-control" placeholder="Enter Price">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="currency">Currency</label>
                            <select class="form-control currency" required name="currency">
                                <option value="">Select currency</option>
                                <option <?php echo e(old('currency') == 'USD' ? 'selected' : ''); ?> value="USD">USD (United States
                                    Dollar)</option>
                                <option <?php echo e(old('currency') == 'ZAR' ? 'selected' : ''); ?> value="ZAR">ZAR (South African
                                    Rand)</option>
                                <option <?php echo e(old('currency') == 'ZWL' ? 'selected' : ''); ?> value="ZWL">ZWL (Zimbabwean
                                    Dollar)</option>

                            </select>
                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <h5 class="h5 mt-4">Images</h5>
                    <hr>
                    <div class="form-group">
                        <label class="form-control-label" for="title">Select Featured Image *</label>
                        <div class="custom-file">
                            <input value="<?php echo e(old('featured_image')); ?>" required="" type="file" accept="image/*"
                                class="custom-file-input" name="featured_image">
                            <label class="custom-file-label" for="featured_image">Choose file</label>
                        </div>
                        <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_2')); ?>" type="file" accept="image/*" class="custom-file-input"
                                    name="image_2">
                                <label class="custom-file-label" for="image_2">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_2')); ?>" type="file" accept="image/*" class="custom-file-input"
                                    name="image_2">
                                <label class="custom-file-label" for="image_2">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <input value="0" required="" type="hidden" name="status">

                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        
        </div>
    </div>
    <!-- /container -->
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/add_listing.blade.php ENDPATH**/ ?>
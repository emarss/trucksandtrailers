<div class="widget">
    <div class="widget--title">
        <h2 class="h4">Lattest News</h2>
        <i class="icon fa fa-newspaper-o"></i>
    </div>

    <!-- List Widgets Start -->
    <div class="list--widget list--widget-1">
        <!-- Post Items Start -->
        <div class="post--items post--items-3" data-ajax-content="outer">
            <ul class="nav" data-ajax-content="inner">
                <?php $__currentLoopData = \Helper::getRecentPosts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo $__env->make("inc.post-format-two", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <!-- Post Items End -->
    </div>
    <!-- List Widgets End -->
</div><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/recent_posts_widget.blade.php ENDPATH**/ ?>
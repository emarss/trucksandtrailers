<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title> <?php echo e(config('app.name', "Staff")); ?> Admin | <?php echo e($pageTitle); ?></title>
  <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
  <div class="mdk-drawer-layout js-mdk-drawer-layout" data-fullbleed data-push data-responsive-width="992px" data-has-scrolling-region>

    <div class="mdk-drawer-layout__content">
      <!-- header-layout -->
      <div class="mdk-header-layout js-mdk-header-layout  mdk-header--fixed  mdk-header-layout__content--scrollable">
        <!-- header -->
        <div class="mdk-header js-mdk-header bg-primary" data-fixed>
            <div class="mdk-header__content">
                <?php echo $__env->make('admin.includes.nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <!-- content -->
        <div class="mdk-header-layout__content top-navbar mdk-header-layout__content--scrollable h-100">
            <!-- main content -->
            <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
      </div>

    </div>
    <!-- // END drawer-layout__content -->

    <!-- drawer -->
    <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
      <div class="mdk-drawer__content">
        <div class="mdk-drawer__inner" data-simplebar data-simplebar-force-enabled="true">
            <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
    <!-- // END drawer -->


  </div>
  <!-- // END drawer-layout -->

  <?php echo $__env->make('admin.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>
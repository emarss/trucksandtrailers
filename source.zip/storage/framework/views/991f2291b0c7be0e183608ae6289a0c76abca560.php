<!-- Vendor -->
<script src="/vendor/jquery/jquery.min.js"></script>
<script src="/vendor/jquery.appear/jquery.appear.min.js"></script>
<script src="/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="/vendor/popper/umd/popper.min.js"></script>
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/jquery.validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/jquery.cookie/jquery.cookie.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/jquery.gmap/jquery.gmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/lazysizes/lazysizes.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/isotope/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/vide/jquery.vide.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/vivus/vivus.min.js')); ?>"></script>

<!-- Theme Base, Components and Settings -->
<script src="<?php echo e(asset('/js/theme.js')); ?>"></script>


<!-- Revolution Slider Addon - Typewriter -->
<script type="text/javascript" src="/vendor/rs-plugin/revolution-addons/typewriter/js/revolution.addon.typewriter.min.js"></script>

<!-- Theme Custom -->
<script src="<?php echo e(asset('/js/custom.js')); ?>"></script>

<!-- Theme Initialization Files -->
<script src="<?php echo e(asset('/js/theme.init.js')); ?>"></script>
<?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/includes/scripts.blade.php ENDPATH**/ ?>
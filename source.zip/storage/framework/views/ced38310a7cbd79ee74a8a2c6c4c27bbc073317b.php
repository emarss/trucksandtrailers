<?php $__env->startSection('title', $listing->name); ?>
<?php $__env->startSection('content'); ?>

<main>

    <nav class="secondary_nav sticky_horizontal_2">
        <div class="container">
            <ul class="clearfix">
                <li><a href="#description" class="active">Showing Listing</a></li>
            </ul>
        </div>
    </nav>

    <div class="container margin_60_35">
        <div class="row">
            <div class="col-lg-8">
                <div id="carousel_in" class="owl-carousel owl-theme add_bottom_30">
                    <span class="magnific-gallery">
                        <a href="<?php echo e(Storage::url("listings/images/$listing->featured_image")); ?>" class="btn_photos"
                            title="Photo title" data-effect="mfp-zoom-in">

                            <div class="strip grid">
                                <figure style="height: 400px">
                                    <a href="<?php echo e(Storage::url("listings/images/$listing->featured_image")); ?>">
                                        <img src="<?php echo e($listing->featuredImage()); ?>" class="img-fluid" alt="">
                                        <div class="read_more"><span>View Photos</span></div>
                                    </a>
                                </figure>
                            </div>
                        </a>
                        <?php if(strlen($listing->image_2) != 0): ?>
                            <a href="<?php echo e(Storage::url("listings/images/$listing->image_2")); ?>" title="Photo title"
                                data-effect="mfp-zoom-in"></a>
                        <?php endif; ?>
                        <?php if(strlen($listing->image_3) != 0): ?>
                            <a href="<?php echo e(Storage::url("listings/images/$listing->image_3")); ?>" title="Photo title"
                                data-effect="mfp-zoom-in"></a>
                        <?php endif; ?>
                    </span>
                </div>

                <section id="description">
                    <div class="detail_title_1">
                        <div class="cat_star"><i class="icon_star"></i><i class="icon_star"></i><i
                                class="icon_star"></i><i class="icon_star"></i></div>
                        <h1><?php echo e($listing->name); ?> <small class="address"
                                style="font-size: 14px"><?php echo e(Str::ucfirst($listing->condition)); ?></small></h1>
                        <a class="address"><?php echo e($listing->location); ?></a>

                    </div>
                    <p><?php echo $listing->description; ?></p>

                </section>
                <!-- /section -->
            </div>
            <!-- /col -->

            <aside class="col-lg-4" id="sidebar">
                <div class="box_detail booking">
                    <div class="price">
                        <span><?php echo e($listing->getPrice()); ?> <small><?php echo e($listing->currency); ?></small></span>
                    </div>
                    <a href="tel:<?php echo e($listing->cell_number); ?>" class=" add_top_30 btn_1 full-width purchase">Call Owner</a>
                    <a href="sms:<?php echo e($listing->cell_number); ?>" class="btn_1 full-width outline wishlist"><i class="fa fa-comment mr-2"></i> Sent SMS</a>
                    <?php if(strlen($listing->email) != 0): ?><a href="mailto:<?php echo e($listing->email); ?>"
                            class="btn_1 full-width outline wishlist"><i class="fa fa-envelope mr-1"></i> Sent Email</a>
                    <?php endif; ?>
                    <?php if(strlen($listing->email) != 0): ?><a href="https://wa.me/<?php echo e($listing->whatsapp_number); ?>"
                            class="btn_1 full-width outline wishlist"><i class="fa fa-whatsapp mr-1"></i> WhatsApp</a>
                    <?php endif; ?>
                </div>
                <ul class="share-buttons">
                    <div class="sharethis-inline-share-buttons"></div>
                </ul>
            </aside>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->

</main>
<!--/main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- CAROUSEL -->
<script>
    $('#carousel_in').owlCarousel({
        center: false,
        items: 1,
        loop: false,
        margin: 0
    });
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
<script src="https://use.fontawesome.com/033e6e96f8.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/listing-show.blade.php ENDPATH**/ ?>
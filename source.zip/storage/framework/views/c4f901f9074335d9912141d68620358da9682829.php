
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      	<h4 class="card-title">
        	<?php echo e($pageTitle); ?>

          <a href="<?php echo e(route('admin.defenders.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
      	</h4>
    </div>
    <div class="card-body">
      <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <b>Case</b>
            </h4>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Image</b></h4>
        </div>
        <div class="card-body text-center">
            <img src="<?php echo e($defender->getPath()); ?>" width="400" alt="" class="img-thumbnail">
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Name</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->name; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Status</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->status; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Description</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->description; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Description</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->description; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Violations</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->violations; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Location</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->location; ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Date</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo $defender->date->format("d M, Y"); ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Created By</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($defender->user->name); ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Created At</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($defender->created_at->diffForHumans()); ?>

            </p>
        </div>
        <div class="card-header">
            <h4 class="card-title"><b>Last Updated</b></h4>
        </div>
        <div class="card-body">
            <p class="card-text">
                <?php echo e($defender->updated_at->diffForHumans()); ?>

            </p>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/admin/defenders/show.blade.php ENDPATH**/ ?>
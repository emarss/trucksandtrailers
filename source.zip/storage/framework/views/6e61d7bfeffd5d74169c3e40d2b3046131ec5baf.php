<?php $__env->startSection('content'); ?>
<br>
		<div class="main-content--section pbottom--30">
				<div class="container">
						
						<?php if($defenders->count()): ?>
							    <!-- Counter Section Start -->
						    <div class="counter--section">
						        <div class="row just gutter--0 odd bg--color-1">
						            <div class=" text-center">
						                <h1 class="">Human Rights Cases</h1>
						            </div><hr>
						            <?php $__currentLoopData = $defenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $defender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							            <div class="col-md-3 col-xs-6 col-xxs-12">
							                <div class="defender--item  p-3 p-lg-5 <?php if($loop->even): ?> even <?php else: ?> odd <?php endif; ?> bg--color-1">
							                	<h4><b class="text-uppercase">Status: <?php echo e($defender->status); ?></b></h4>
							                	<img  src="<?php echo e($defender->thumbnail()); ?>" alt="" class="img-thumbnail">
							                	<h4><?php echo e($defender->name); ?></h4>
							                	<p><small><?php echo e($defender->date->format("d M, Y")); ?></small> </p>
							                    <p><?php echo e($defender->description); ?></p>
							                    <p><b>Violations:</b> <?php echo e($defender->violations); ?></p>
							                    <p><b>Location:</b> <?php echo e($defender->location); ?></p>
							                </div>
							                <!-- Counter Item End -->
							            </div>
						            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        </div>
						    </div>
						    <!-- Counter Section End -->
						<?php endif; ?>
				</div>
		</div>
		<!-- Main Content Section End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/defenders.blade.php ENDPATH**/ ?>
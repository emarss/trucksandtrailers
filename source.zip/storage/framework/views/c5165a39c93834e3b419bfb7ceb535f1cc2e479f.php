<nav class="drawer drawer--dark">
  <div class="drawer-spacer">
    <div class="media align-items-center">
      <a href="<?php echo e(route('admin.home')); ?>" class="drawer-brand-circle bg-white mr-2">
        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="logo" class="img-fluid rounded-circle">
      </a>
      <div class="media-body">
        <a href="<?php echo e(route('admin.home')); ?>" class="h5 m-0 text-link"><?php echo e(config('app.name')); ?> - Admin</a>
      </div>
    </div>
  </div>
  <!-- HEADING -->
  <div class="py-2 drawer-heading">
    Dashboards
  </div>
  <!-- DASHBOARDS MENU -->
  <ul class="drawer-menu">
    <li class="drawer-menu-item">
      <a href="<?php echo e(route('admin.home')); ?>">
        <i class="material-icons">home</i>
        <span class="drawer-menu-text"> Home</span>
      </a>
    </li>

    <li class="drawer-menu-item drawer-submenu">
      <a data-toggle="collapse" data-parent="#pagesMenu" href="#" data-target="#extrasMenu" aria-controls="extrasMenu"  aria-expanded="false"  class="collapsed">
        <i class="material-icons">assignment</i>
        <span class="drawer-menu-text"> Posts</span>
      </a>
      <ul class="collapse" id="extrasMenu">
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.posts.index')); ?>">Posts</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.posts.create')); ?>">Add Post</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.posts.categories.index')); ?>">Categories</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.posts.categories.create')); ?>">Add Category</a></li>
      </ul>
    </li> 


    <li class="drawer-menu-item drawer-submenu">
      <a data-toggle="collapse" data-parent="#pagesMenu" href="#" data-target="#documentsMenu" aria-controls="documentsMenu"  aria-expanded="false"  class="collapsed">
        <i class="material-icons">book</i>
        <span class="drawer-menu-text"> Documents</span>
      </a>
      <ul class="collapse" id="documentsMenu">
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.documents.index')); ?>">Documents</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.documents.create')); ?>">Add Document</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.documents.categories.index')); ?>">Categories</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.documents.categories.create')); ?>">Add Category</a></li>
      </ul>
    </li> 

    <li class="drawer-menu-item drawer-submenu">
      <a data-toggle="collapse" data-parent="#pagesMenu" href="#" data-target="#photosMenu" aria-controls="photosMenu"  aria-expanded="false"  class="collapsed">
        <i class="material-icons">perm_media</i>
        <span class="drawer-menu-text"> Photos</span>
      </a>
      <ul class="collapse" id="photosMenu">
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.photos.index')); ?>">Photos</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.photos.create')); ?>">Add Photo</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.photos.categories.index')); ?>">Categories</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.photos.categories.create')); ?>">Add Category</a></li>
      </ul>
    </li> 

    <li class="drawer-menu-item drawer-submenu">
      <a data-toggle="collapse" data-parent="#pagesMenu" href="#" data-target="#usersMenu" aria-controls="usersMenu"  aria-expanded="false"  class="collapsed">
        <i class="material-icons">people</i>
        <span class="drawer-menu-text"> Users</span>
      </a>
      <ul class="collapse" id="usersMenu">
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.users.index')); ?>">Users</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.users.create')); ?>">Add User</a></li>
      </ul>
    </li> 

    <li class="drawer-menu-item drawer-submenu">
      <a data-toggle="collapse" data-parent="#pagesMenu" href="#" data-target="#videosMenu" aria-controls="videosMenu"  aria-expanded="false"  class="collapsed">
        <i class="material-icons">video_library</i>
        <span class="drawer-menu-text"> Videos</span>
      </a>
      <ul class="collapse" id="videosMenu">
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.videos.index')); ?>">Videos</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.videos.create')); ?>">Add Video</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.videos.categories.index')); ?>">Categories</a></li>
        <li class="drawer-menu-item"><a href="<?php echo e(route('admin.videos.categories.create')); ?>">Add Category</a></li>
      </ul>
    </li>
    <li class="drawer-menu-item drawer-submenu">
      <a href="<?php echo e(route('admin.newsletters.index')); ?>" >
        <i class="material-icons">contact_mail</i>
        <span class="drawer-menu-text"> Subscribers</span>
      </a>
    </li>
    <li class="drawer-menu-item drawer-submenu">
      <a href="<?php echo e(route('admin.feedback.index')); ?>" >
        <i class="material-icons">feedback</i>
        <span class="drawer-menu-text"> Feedback</span>
      </a>
    </li> 

    <div class="sticky-bottom" style="position: absolute; bottom: 0;">
      <div class="py-2 drawer-heading"> Account </div>
      <li class="drawer-menu-item drawer-submenu">
        <a href="<?php echo e(route('admin.profile')); ?>" >
          <i class="material-icons">person</i>
          <span class="drawer-menu-text"> Profile</span>
        </a>
      </li>
      <li class="drawer-menu-item drawer-submenu">
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
          <i class="material-icons">exit_to_app</i>
          <span class="drawer-menu-text"> Logout</span>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
        </form>
      </li>       
    </div>

  </ul>

</nav><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>
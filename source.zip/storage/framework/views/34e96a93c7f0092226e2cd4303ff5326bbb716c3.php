<script src="<?php echo e(asset('js/common_scripts.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('js/markerclusterer.js')); ?>"></script>


<?php if(Session::has("feedback")): ?>
    <div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
        <div class="small-dialog-header">
            <h3><?php echo e(Session("title")); ?></h3>
        </div>
        <div class="text-center">
            <?php echo e(Session("message")); ?>

        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Modal Sign In
            $.magnificPopup.open({
                items: {
                    src: '#sign-in-dialog'
                },
                type: 'inline',
                closeMarkup: '<button title="%title%" type="button" class="mfp-close"></button>',
            });

        });
    </script>
<?php endif; ?>
<?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/includes/scripts.blade.php ENDPATH**/ ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($pageTitle); ?>

                <a href="<?php echo e(route('admin.listings.edit', $listing->id)); ?>" class="btn btn-primary btn-sm float-right">Edit
                    listing</a>
            </h4>
        </div>
        <div class="card-body">
            <div class="card">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Name</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                 <?php echo e($listing->name); ?>

                                 <span class="badge <?php echo e($listing->status == 1 ? "badge-primary" : "badge-danger"); ?> py-1"><?php echo e($listing->getStatus()); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card-header">
                            <h4 class="card-title"><b>Price</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->price); ?> <?php echo e($listing->currency); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card-header">
                            <h4 class="card-title"><b>Priority</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->priority); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-header">
                    <h4 class="card-title"><b>Descripion</b></h4>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php echo $listing->description; ?>

                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Condition</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e(ucfirst($listing->condition)); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Category</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e(ucwords($listing->getCategory())); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Cell Number</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->cell_number); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>WhatsApp Number</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->whatsapp_number); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Location</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e(ucfirst($listing->location)); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-header">
                            <h4 class="card-title"><b>Email Address</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->email); ?>

                            </p>
                        </div>
                    </div>
                </div>
               
                <div class="card-header">
                    <h4 class="card-title"><b>Featured Image</b></h4>
                </div>
                <div class="card-body row">
                    <div class="col-md-4">
                        <p class="card-text">
                            <img src="<?php echo e(Storage::url("public/listings/images/$listing->featured_image")); ?>"
                                alt="<?php echo e($listing->title); ?>" height="200">
                        </p>
                    </div>

                    <div class="col-md-4">
                        <p class="card-text">
                            <?php if(strlen($listing->image_2) != 0): ?>
                                <img src="<?php echo e(Storage::url("public/listings/images/$listing->image_2")); ?>"
                                    alt="<?php echo e($listing->title); ?>" height="200">
                            <?php else: ?>
                                <span class="text-info">Not available</span>
                            <?php endif; ?>
                        </p>
                    </div>

                    <div class="col-md-4">
                        <p class="card-text">
                            <?php if(strlen($listing->image_3) != 0): ?>
                                <img src="<?php echo e(Storage::url("public/listings/images/$listing->image_3")); ?>"
                                    alt="<?php echo e($listing->title); ?>" height="200">
                            <?php else: ?>
                                <span class="text-info">Not available</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Created By</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->user->name); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Created At</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->created_at->diffForHumans()); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card-header">
                            <h4 class="card-title"><b>Last Updated</b></h4>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($listing->updated_at->diffForHumans()); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/admin/listings/show.blade.php ENDPATH**/ ?>
<!-- News Ticker Start -->
<div class="news--ticker">
    <div class="container">
        <div class="title">
            <h2>News Updates</h2>
        </div>

        <div class="news-updates--list" data-marquee="true">
            <ul class="nav">
                <?php $__currentLoopData = \Helper::getRecentPosts(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <h3 class="h3"><a href="<?php echo e(route('blog.show', $post->id)); ?>"><?php echo e(Str::limit($post->title,50)); ?></a></h3>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/news-ticker.blade.php ENDPATH**/ ?>
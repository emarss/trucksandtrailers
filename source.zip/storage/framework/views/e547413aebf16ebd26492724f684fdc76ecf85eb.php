<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-10">
                        <h4><?php echo e($pageTitle); ?></h4>
                    </div>
                    <div class="col-md-8 col-2">
                        <a href="#0" class="side_panel btn_search_mobile"></a>
                        <!-- /open search panel -->
                        <form method="POST" action="<?php echo e(route('search')); ?>"
                            class="row no-gutters custom-search-input-2 inner">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-7">
                                <div class="form-group">
                                    <input <?php if(isset($prevSearch)): ?> value="<?php echo e($prevSearch); ?>"
                                    <?php endif; ?>  class="form-control" name="search" type="text"
                                        placeholder="What are you looking for...">
                                    <i class="icon_search"></i>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <select name="category" class="wide">
                                    <option value="">All Categories</option>
                                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(isset($prevCategory)): ?> <?php echo e($prevCategory == $category->id ? 'selected' : ''); ?>

                                            <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e(ucwords($category->category)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-lg-1">
                                <input type="submit">
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>

        <!-- /results -->
        

        <div class="container margin_60_35">

            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="strip grid">
                            <figure>
                                <a class="price_bt"><?php echo e($listing->getPrice()); ?> <?php echo e($listing->currency); ?></a>
                                <a href="<?php echo e(route('listing.show', $listing->slug)); ?>"><img
                                        src="<?php echo e($listing->featuredImage()); ?>" class="img-fluid" alt="">
                                    <div class="read_more"><span>Read more</span></div>
                                </a>
                                <small><?php echo e($listing->getCategory()); ?></small>
                            </figure>
                            <div class="wrapper">
                                <h3><a href="<?php echo e(route('listing.show', $listing->slug)); ?>"><?php echo e($listing->name); ?></a>
                                </h3>
                                <small>Condition: <?php echo e(Str::ucfirst($listing->condition)); ?></small>
                                <p><?php echo e($listing->except()); ?></p>
                            </div>
                            <ul>
                                <li><a href="<?php echo e(route('listing.show', $listing->slug)); ?>"
                                        class="btn_2 font-weight-bold">View Details</a></li>
                                <li><a href="tel:<?php echo e($listing->cell_number); ?>" class="btn_3 btn-danger ml-2"><i
                                            class="icon-call"></i></a></li>

                                <?php if(strlen($listing->email) != 0): ?>
                                    <li><a href="mailto:<?php echo e($listing->email); ?>" class="btn_3 btn-danger ml-2"><i
                                                class="icon-email"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center col-md-12 mb-5 mt-4">
                        No results found.
                    </div>
                <?php endif; ?>

            </div>
            <?php echo e($listings->links()); ?>

            <!-- /row -->

            

        </div>
        <!-- /container -->

    </main>
    <!--/main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/search.blade.php ENDPATH**/ ?>
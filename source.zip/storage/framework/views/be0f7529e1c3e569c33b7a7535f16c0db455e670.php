<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">


                        <h1 class="text-dark font-weight-bold text-8">Show Project</h1>
                        <span class="sub-title text-dark"><?php echo e($project->title); ?></span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('projects')); ?>">Projects</a></li>
                            <li class="active">Show</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-4">

            <div class="row pt-4 mt-2 mb-5">
                <div class="col-md-7 mb-4 mb-md-0">
                    <div class="col appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="300">
                        <div class="img-thumbnail border-0 border-radius-0 p-0 d-block">
                            <img src="<?php echo e($project->featuredImage()); ?>" class="img-fluid w-100 border-radius-0" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <h2 class="text-color-dark font-weight-normal text-5 mb-1"><strong><?php echo e($project->title); ?></strong></h2>

                    <p class="my-1"><?php echo $project->body; ?></p>


                    <ul class="list list-icons list-primary list-borders text-2">
                        <li><i class="fas fa-caret-right left-10"></i> <strong
                                            class="text-color-primary">Project URL:</strong> <a href="<?php echo e($project->url); ?>" class="btn-link"><?php echo e($project->url); ?></a></li>
                        <li><i class="fas fa-caret-right left-10"></i> <strong class="text-color-primary">Audience:</strong> <?php echo e($project->audience); ?></li>
                        <li><i class="fas fa-caret-right left-10"></i> <strong class="text-color-primary">Date:</strong> <?php echo e($project->date->format('M, Y')); ?></li>
                        <li><i class="fas fa-caret-right left-10"></i> <strong
                            class="text-color-primary">Skills:</strong>
                            <?php $__currentLoopData = $project->skills(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span
                            class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1"><?php echo e($skill); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    </ul>

                </div>

                <div class="col">
                    <hr class="solid my-5">

                    <strong class="text-uppercase text-1 mr-3 text-dark float-left position-relative top-2">Share</strong>
                    <ul class="social-icons">
                        <li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                        <li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                        <li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/projects-show.blade.php ENDPATH**/ ?>
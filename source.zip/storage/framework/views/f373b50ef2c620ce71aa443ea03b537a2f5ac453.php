<div class="row">
    <div class="col-xs-1">
        <a href="<?php echo e($document->getPath()); ?>" class="thumb">
            <i class="fa fa-file-pdf-o" style="font-size: 3rem"></i>
        </a>
    </div>
    <div class="col-xs-11">
        <div class="post--info">
            <div class="title">
                <a href="<?php echo e($document->getPath()); ?>" class="btn-link"><?php echo $document->description; ?></a>
            </div>                                    
            <ul class="nav meta justify-content-between">
                <li><a href="<?php echo e($document->getPath()); ?>" class="mr-5">Download</a></li>
                <li><a><?php echo e($document->created_at->diffForHumans()); ?></a></li>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/document-format-one.blade.php ENDPATH**/ ?>
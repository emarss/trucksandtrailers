<!-- Widget Start -->
<div class="widget">
    <div class="widget--title">
        <h2 class="h4">Catagory</h2>
        <i class="icon fa fa-folder-open-o"></i>
    </div>

    <!-- Nav Widget Start -->
    <div class="nav--widget">
        <ul class="nav">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('blog.search', $category->category)); ?>"><span><?php echo e($category->categoryName()); ?></span><span>(<?php echo e($category->postsCount()); ?>)</span></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <!-- Nav Widget End -->
</div>
<!-- Widget End --><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/all_categories.blade.php ENDPATH**/ ?>
<!-- Sticky Social Start -->
<div id="stickySocial" class="sticky--right">
    <ul class="nav">
        <li>
            <a target="_blank" href="https://www.facebook.com/Zimbabwe-Human-Rights-Monitors-Platform-115556003550202">
                <i class="fa fa-facebook"></i>
                <span>Follow Us On Facebook</span>
            </a>
        </li>
        <li>
            <a target="_blank" href="https://twitter.com/HumanDefendes">
                <i class="fa fa-twitter"></i>
                <span>Follow Us On Twitter</span>
            </a>
        </li>
        <li>
            <a target="_blank" href="https://www.youtube.com/channel/UCtnawD23IxgW-jqZFjSpTbg">
                <i class="fa fa-youtube-play"></i>
                <span>Follow Us On Youtube Play</span>
            </a>
        </li>
    </ul>
</div>
<!-- Sticky Social End -->

<!-- Back To Top Button Start -->
<div id="backToTop">
    <a href="#"><i class="fa fa-angle-double-up"></i></a>
</div>
<!-- Back To Top Button End -->

<?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/inc/stickies.blade.php ENDPATH**/ ?>
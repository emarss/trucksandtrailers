
<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/css/vendor-summernote.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
      </div>
      <div class="card-body">
        <form method="post" action="<?php echo e(route('admin.defenders.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="form-control-label" for="name">Full Name * </label>
            <input required="" type="text" class="form-control" placeholder="Enter full name" name="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="status">Status * </label>
            <input required="" type="text" class="form-control" placeholder="eg. Imprisoned/Convicted." name="status">
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="title">Select Image *</label>
            <div class="custom-file">
              <input required="" type="file" accept="image/*"  class="custom-file-input" name="avatar">
              <label class="custom-file-label" for="avatar">Choose file</label>
            </div>
            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="formGroupExampleInput2">Description *</label>
            <textarea name="description" placeholder="Enter the description" class="form-control"><?php echo old('description'); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="violations">Violations *</label>
            <input required="" type="text" class="form-control" placeholder="Enter violations" name="violations">
            <?php $__errorArgs = ['violations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="location">Location * </label>
            <input required="" type="text" class="form-control" placeholder="Enter location." name="location">
            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="date">Date * </label>
            <input required="" type="date" class="form-control" value="<?php echo e(now()->format("Y-m-d")); ?>" name="date">
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
       
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('admin/vendor/summernote-bs4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/select2.full.min.js')); ?>"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js'></script>

    <script>
        $('.categories').select2({
            theme: 'bootstrap',
            placeholder: 'Select an option',
        });
        $('.tags').select2({
            theme: 'bootstrap',
            placeholder: 'Add Tags',
            tags: true,
            tokenSeparators: [',', ';'],
            "language":{
              "noResults" : function () { return ''; }
            }

        });
        $('.text-editor').summernote({
            height: '200',
            dialogsInBody: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/admin/defenders/create.blade.php ENDPATH**/ ?>
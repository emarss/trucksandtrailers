<div class="container-fluid">
	<?php if(Session::has('success')): ?>
		<div class="alert alert-info alert-dismissible">
			<a class="close" data-dismiss="alert">&times;</a>		
			Success: <?php echo e(Session::get('message')); ?>

		</div>
	<?php endif; ?>

	<?php if(Session::has('fail')): ?>
		<div class="alert alert-danger alert-dismissible">
			<a class="close" data-dismiss="alert">&times;</a>		
			Fail: <?php echo e(Session::get('message')); ?>

		</div>
	<?php endif; ?>

	<?php if(Session::has('error')): ?>
		<div class="alert alert-danger alert-dismissible">
			<a class="close" data-dismiss="alert">&times;</a>		
			Error: <?php echo e(Session::get('message')); ?>

		</div>
	<?php endif; ?>
</div><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/admin/includes/messages.blade.php ENDPATH**/ ?>
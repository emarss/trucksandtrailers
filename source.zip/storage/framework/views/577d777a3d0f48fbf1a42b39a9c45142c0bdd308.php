<?php $__env->startSection('content'); ?>
     <!-- Main Content Section Start -->
    <div class="main-content--section pbottom--30">
        <div class="container">
            <!-- Main Content Start -->
            <div class="main--content">
                <!-- Post Item Start -->
                <div class="post--item post--single pd--30-0">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="post--video embed-responsive embed-responsive-16by9">
                                <!-- <iframe src="https://www.youtube.com/watch?v=8XD-T2xmLHc?rel=0&amp;controls=0&amp;showinfo=0&amp;wmode=transparent" allowfullscreen></iframe> -->
                                <iframe src="https://www.youtube.com/embed/8XD-T2xmLHc?rel=0&amp;controls=0&amp;showinfo=0&amp;wmode=transparent" allowfullscreen></iframe>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="post--info">
                                <div class="title">
                                    <h2 class="h4">Rule of Law is our Priority</h2>
                                </div>
                            </div>

                            <div class="post--content">
                                <p class="text-justify">When you deprive people of their right to live in dignity, to hope for a better future, to have control over their lives, when you deprive them of that choice, then you expect them to fight for these rights</p>
                                <p class="text-justify">Our hopes for a more just, safe, and peaceful Zimbabwe can only be achieved when there is universal respect for the rule of law and equal rights of all members of the nation.</p>
                                <p class="text-justify">There can be no peace without development, no development without peace, and no lasting peace or sustainable development without respect for human rights and the rule of law</p>
                                <p class="text-justify">As the great Nelson Mandela said, "To deny people their human rights is to challenge their very humanity"</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Post Item End -->

                <!-- Info Blocks Start -->
                <div class="info--blocks ptop--30">
                    <ul class="nav row">
                        <li class="col-md-3 col-xs-6 col-xxs-12 pbottom--30">
                            <!-- Info Block Start -->
                            <div class="info--block">
                                <div class="icon text--color-1">
                                    <i class="fa fa-dashboard"></i>
                                </div>

                                <div class="title">
                                    <h3 class="h5">Our Vision</h3>
                                </div>

                                <div class="content">
                                    <p>An inclusive, peaceful and democratic zimbabwe with strong social cohesion and sustainable development championed through the realisation and respect of human rights.</p>
                                </div>
                            </div>
                            <!-- Info Block End -->
                        </li>

                        <li class="col-md-3 col-xs-6 col-xxs-12 pbottom--30">
                            <!-- Info Block Start -->
                            <div class="info--block">
                                <div class="icon text--color-1">
                                    <i class="fa fa-cog"></i>
                                </div>

                                <div class="title">
                                    <h3 class="h5">Our Mission</h3>
                                </div>

                                <div class="content">
                                    <p>To transform Zimbabwe into a Democratic Developmental state and protect Human Rights Defenders through training and education, research, advocacy, campaign and lobbying and litigation services.</p>
                                </div>
                            </div>
                            <!-- Info Block End -->
                        </li>

                        <li class="col-md-3 col-xs-6 col-xxs-12 pbottom--30">
                            <!-- Info Block Start -->
                            <div class="info--block">
                                <div class="icon text--color-1">
                                    <i class="fa fa-diamond"></i>
                                </div>

                                <div class="title">
                                    <h3 class="h5">Our Values</h3>
                                </div>

                                <div class="content">
                                    <p>Transparency and Accountability, Equity and Gender Equality, Action and Innovation, Diverse Collaboration and Solidarity.</p>
                                </div>
                            </div>
                            <!-- Info Block End -->
                        </li>

                        <li class="col-md-3 col-xs-6 col-xxs-12 pbottom--30">
                            <!-- Info Block Start -->
                            <div class="info--block">
                                <div class="icon text--color-1">
                                    <i class="fa fa-object-group"></i>
                                </div>

                                <div class="title">
                                    <h3 class="h5">Our Focus</h3>
                                </div>

                                <div class="content">
                                    <p>On economic, social, cultural, civil, and political rights, Citizenship Education, transparency and accountability , Transitional Justice, Good Governance.</p>
                                </div>
                            </div>
                            <!-- Info Block End -->
                        </li>
                    </ul>
                </div>
                <!-- Info Blocks End -->
            </div>
            <!-- Main Content End -->
        </div>
    </div>
    <!-- Main Content Section End -->

    <!-- Counter Section Start -->
    <div class="counter--section">
        <div class="row gutter--0 odd bg--color-1">
            <div class=" text-center">
                <h1 class="">CORE PROGRAMS</h1>
            </div><hr>
            <div class="col-md-3 col-xs-6 col-xxs-12">
                <!-- Counter Item Start -->
                <div class="defender--item odd bg--color-1">
                    <h4 class="text-center">Research and Publishing & Transitional Justice</h4>
                </div>
                <!-- Counter Item End -->
            </div>

            <div class="col-md-3 col-xs-6 col-xxs-12">
                <!-- Counter Item Start -->
                <div class="defender--item even bg--color-1">
                    <h4 class="text-center">Exchange Program & Peace Building Initiative</h4>
                </div>
                <!-- Counter Item End -->
            </div>

            <div class="col-md-3 col-xs-6 col-xxs-12">
                <!-- Counter Item Start -->
                <div class="defender--item odd bg--color-1">
                    <h4 class="text-center">Policy Analysis and Advocacy</h4>
                </div>
                <!-- Counter Item End -->
            </div>

            <div class="col-md-3 col-xs-6 col-xxs-12">
                <!-- Counter Item Start -->
                <div class="defender--item even bg--color-1">
                    <h4 class="text-center">Capacity Building & Solidarity and Support</h4>
                </div>
                <!-- Counter Item End -->
            </div>
        </div>
    </div>
    <!-- Counter Section End -->

    <!-- Single Image Section Start -->
    <div class="single-img--section ptop--30">
        <div class="container">
            <img src="img/about-img/team.jpg" alt="" class="center-block">
        </div>
    </div>
    <!-- Single Image Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/about.blade.php ENDPATH**/ ?>
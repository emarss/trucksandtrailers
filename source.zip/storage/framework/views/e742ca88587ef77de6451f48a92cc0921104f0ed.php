<!-- Widget Start -->
<div class="widget">
    <div class="widget--title">
        <h2 class="h4">Stay Connected</h2>
        <i class="icon fa fa-share-alt"></i>
    </div>

    <!-- Social Widget Start -->
    <div class="social--widget style--1">
        <ul class="nav">
            <li class="facebook">
                <a href="https://www.facebook.com/Zimbabwe-Human-Rights-Monitors-Platform-115556003550202">
                    <span class="icon"><i class="fa fa-facebook-f"></i></span>
                    <span class="count">+300</span>
                    <span class="title">Likes</span>
                </a>
            </li>
            <li class="twitter">
                <a href="https://twitter.com/HumanDefendes">
                    <span class="icon"><i class="fa fa-twitter"></i></span>
                    <span class="count">+200</span>
                    <span class="title">Followers</span>
                </a>
            </li>
            <li class="youtube">
                <a href="https://www.youtube.com/channel/UCtnawD23IxgW-jqZFjSpTbg">
                    <span class="icon"><i class="fa fa-youtube-square"></i></span>
                    <span class="count">+50</span>
                    <span class="title">Subscriber</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- Social Widget End -->
</div>
<!-- Widget End --><?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/inc/socials.blade.php ENDPATH**/ ?>
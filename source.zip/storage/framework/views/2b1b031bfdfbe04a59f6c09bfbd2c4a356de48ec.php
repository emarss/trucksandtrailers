
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">
          <?php echo e($pageTitle); ?>

          <a href="<?php echo e(route('admin.videos.categories.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
        </h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
          <table class="table table-sm table-striped table-hover" id="data-table">
              <thead class="thead-dark">
                <tr>
                    <th scope="col" class="text-center">#</th>
                    <th scope="col" class="text-center">Category</th>
                    <th scope="col" class="text-center">Description</th>
                    <th scope="col" class="text-center">Created By</th>
                    <th scope="col" class="text-center">Last Updated</th>
                    <th scope="col" class="text-center">Actions</th>
                </tr>
              </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th class="align-middle text-center" scope="row"><?php echo e($category->id); ?></th>
                    <td><?php echo e($category->categoryName()); ?></th>
                    <td><?php echo $category->description; ?></th>
                    <td><?php echo e($category->user->name); ?></th>
                    <td><?php echo e($category->updated_at->diffForHumans()); ?></th>
                    <td class="align-middle text-center">
                      <a href="<?php echo e(route('admin.videos.categories.edit', $category->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                      <button onclick="confirmDelete('<?php echo e(route('admin.videos.categories.destroy', $category->id)); ?>')" class="btn btn-sm btn-danger">Delete</button>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7">No categories found. Click <a href="<?php echo e(route('videos.categories.create')); ?>">this link</a> to create new.</td>
                </tr>
              <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
      $(document).ready(function() {
          $('#data-table').DataTable( {
              "order": [[ 3, "desc" ]]
          } );
      } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/videos/categories/index.blade.php ENDPATH**/ ?>
<div class="widget">
    <div class="widget--title">
        <h2 class="h4">Get Newsletter</h2>
        <i class="icon fa fa-envelope-open-o"></i>
    </div>

    <div class="subscribe--widget">
        <div class="content">
            <p>Subscribe to our newsletter to get  latest news, popular news and exclusive updates.</p>
        </div>

        <form action="<?php echo e(route('newsletter')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <input value="<?php echo e(old('email')); ?>" type="email" name="email" placeholder="E-mail address" class="form-control" required>
                <div class="input-group-btn">
                    <button type="submit" class="btn btn-lg btn-default active"><i class="fa fa-paper-plane-o"></i></button>
                </div>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/newsletter-sidebar.blade.php ENDPATH**/ ?>
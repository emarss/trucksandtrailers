<?php $__env->startSection('content'); ?>
        <!-- Main Content Section Start -->
        <div class="main-content--section pbottom--30">
            <div class="container">
                <div class="row">
                   <!-- Main Content Start -->
                    <div class="main--content pd--30-0">
                        <!-- Post Items Title Start -->
                        <div class="post--items-title" data-ajax="tab">
                            <h2 class="h4">Documentaries</h2>

                            <div class="nav">
                                <a href="#" class="prev btn-link">
                                    <i class="fa fa-expand"></i>
                                </a>
                            </div>
                        </div>
                        <!-- Post Items Title End -->

                        <!-- Post Items Start -->
                        <div class="post--items post--items-4" data-ajax-content="outer">
                            <ul class="nav row" data-ajax-content="inner">
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                                <li class="col-md-4 col-12 mt-5">
                                    <!-- Post Item Start -->
                                    <div class="post--item post--layout-1 post--type-video post--title-large">
                                        <div class="post--img">
                                            <a href="news-single-v1-boxed.html" class="thumb"><img src="img/home-img/audio-video-01.jpg" alt=""></a>
                                            <a href="#" class="cat">Wave</a>
                                            <a href="#" class="icon"><i class="fa fa-eye"></i></a>

                                            <div class="post--info">
                                                <ul class="nav meta">
                                                    <li><a href="#">Succubus</a></li>
                                                    <li><a href="#">Today 03:52 pm</a></li>
                                                </ul>

                                                <div class="title">
                                                    <h2 class="h4"><a href="news-single-v1-boxed.html" class="btn-link">Standard chunk of Lorem Ipsum used since the...</a></h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                    <!-- Divider Start -->
                                    <hr class="divider hidden-md hidden-lg">
                                    <!-- Divider End -->
                                </li>
                            </ul>
                        </div>                    
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/documentaries.blade.php ENDPATH**/ ?>
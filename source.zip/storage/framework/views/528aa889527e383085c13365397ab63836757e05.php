
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/vendor-summernote.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('admin.listings.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h5 class="h5">Basic Info</h5>
                    <hr>
                    <div class="form-group">
                        <label class="form-control-label" for="name">Name</label>
                        <input value="<?php echo e(old('name')); ?>" required="" type="text" name="name" class="form-control"
                            placeholder="Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label" for="formGroupExampleInput2">Description</label>
                        <textarea name="description" class="text-editor"><?php echo old('description'); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="condition">Condition</label>
                            <select class="form-control condition" required name="condition">
                                <option <?php echo e(old('condition') == 'new' ? 'selected' : ''); ?> value="new">New</option>
                                <option <?php echo e(old('condition') == 'preowned' ? 'selected' : ''); ?> value="preowned">Preowned
                                </option>
                            </select>
                            <?php $__errorArgs = ['condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Category </label>
                            <select class="form-control category" name="category" required="">
                                <option value=""></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('category') == $category->id ? 'selected' : ''); ?>

                                        value="<?php echo e($category->id); ?>"><?php echo e(ucwords($category->category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="status">Status</label>
                            <select class="form-control" required name="status">
                                <option <?php echo e(old('status') == '1' ? 'selected' : ''); ?> value="1">Approved
                                </option>
                                <option <?php echo e(old('status') == '0' ? 'selected' : ''); ?> value="0">Pending</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="priority">Priority</label>
                            <input value="<?php echo e(old('priority') == "" ? "1" : old('priority')); ?>" required="" type="number" name="priority"
                                class="form-control" placeholder="Enter Priority">
                            <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <h5 class="h5 mt-4">Contact Info</h5>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="cell_number">Cell Number</label>
                            <input pattern="[\+]\d{9,14}" title="Please, enter phone number in international format." value="<?php echo e(old('cell_number')); ?>" required="" type="text" name="cell_number"
                                class="form-control" placeholder="Enter mobile number">
                            <?php $__errorArgs = ['cell_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="whatsapp_number">WhatsApp Number
                                <i>(Optional)</i></label>
                            <input pattern="[\+]\d{9,14}" title="Please, enter phone number in international format." value="<?php echo e(old('whatsapp_number')); ?>" type="text" name="whatsapp_number"
                                class="form-control" placeholder="Enter Whatsapp Number">
                            <?php $__errorArgs = ['whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="location">Location
                            </label>
                            <input value="<?php echo e(old('location')); ?>" required="" type="text" name="location"
                                class="form-control" placeholder="Enter Location">
                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="email">Email Address<i>(Optional)</i></label>
                            <input value="<?php echo e(old('email')); ?>" type="email" name="email" class="form-control"
                                placeholder="Enter Email Address">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <h5 class="h5 mt-4">Pricing</h5>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="price">Price</label>
                            <input value="<?php echo e(old('price')); ?>" required="" type="number" step="0.01" name="price"
                                class="form-control" placeholder="Enter Price">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="currency">Currency</label>
                            <select class="form-control currency" required name="currency">
                                <option <?php echo e(old('currency') == 'USD' ? 'selected' : ''); ?> value="USD">USD (United States
                                    Dollar)</option>
                                <option <?php echo e(old('currency') == 'ZAR' ? 'selected' : ''); ?> value="ZAR">ZAR (South African
                                    Rand)</option>
                                <option <?php echo e(old('currency') == 'ZWL' ? 'selected' : ''); ?> value="ZWL">ZWL (Zimbabwean
                                    Dollar)</option>

                            </select>
                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <h5 class="h5 mt-4">Images</h5>
                    <hr>
                    <div class="form-group">
                        <label class="form-control-label" for="title">Select Featured Image *</label>
                        <div class="custom-file">
                            <input value="<?php echo e(old('featured_image')); ?>" required="" type="file" accept="image/*"
                                class="custom-file-input" name="featured_image">
                            <label class="custom-file-label" for="featured_image">Choose file</label>
                        </div>
                        <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger my-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_2')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_2">
                                <label class="custom-file-label" for="image_2">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_3')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_3">
                                <label class="custom-file-label" for="image_3">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_4')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_4">
                                <label class="custom-file-label" for="image_4">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_5')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_5">
                                <label class="custom-file-label" for="image_5">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_6')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_6">
                                <label class="custom-file-label" for="image_6">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_7')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_7">
                                <label class="custom-file-label" for="image_7">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_8')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_8">
                                <label class="custom-file-label" for="image_8">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-control-label" for="title">Select Another Image <i>(Optional)</i></label>
                            <div class="custom-file">
                                <input value="<?php echo e(old('image_9')); ?>" type="file" accept="image/*"
                                    class="custom-file-input" name="image_9">
                                <label class="custom-file-label" for="image_9">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['image_9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger my-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    

                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('admin/vendor/summernote-bs4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/select2.full.min.js')); ?>"></script>

    <script>
        $('.category').select2({
            theme: 'bootstrap',
            placeholder: 'Select an option',
        });

        $('.text-editor').summernote({
            height: '100',
            dialogsInBody: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Clients/trucks_and_trailers/source/resources/views/admin/listings/create.blade.php ENDPATH**/ ?>
<header class="header--section header--style-2 mt-5">
    <div class="header--navbar navbar bd--color-1" data-trigger="sticky">
        <div class="container">
            <div class="navbar-header">
                <div class="logo pull-left">
                    <a href="/"><img src="<?php echo e(asset('img/nav-logo.png')); ?>" style="max-height: 50px; margin-top: 4px; max-height: 40px; margin: 9px 10px 9px 0px"></a>
                </div>
                <button type="button" class="navbar-toggle collapsed pull-left" style="float: left;" data-toggle="collapse" data-target="#headerNav" aria-expanded="false" aria-controls="headerNav">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <div id="headerNav" class="navbar-collapse collapse float--left">
                <ul class="header--menu-links nav navbar-nav" data-trigger="hoverIntent">
                    <li class="<?php echo e(Request::is('') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>

                    <li class="<?php echo e(Request::is('blog') ? 'active' : ''); ?>"><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                    <li class="<?php echo e(Request::is('photos-gallery') ? 'active' : ''); ?>"><a href="<?php echo e(route('photos-gallery')); ?>">Photos Gallery</a></li>
                    <li class="<?php echo e(Request::is('videos-gallery') ? 'active' : ''); ?>"><a href="<?php echo e(route('videos-gallery')); ?>">Videos Gallery</a></li>
                    <li class="dropdown <?php echo e(Request::is('documents') || Request::is('documentaries') ? 'active' : ''); ?>">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Media Center<i class="fa flm fa-angle-down"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('documentaries')); ?>">Documentaries</a></li>
                            <li><a href="<?php echo e(route('documents')); ?>">Documents</a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e(Request::is('about') ? 'active' : ''); ?>"><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                    <li class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                    <li class="dropdown <?php echo e(Request::is('cookies') || Request::is('privacy') || Request::is('terms') ? 'active' : ''); ?>">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">More<i class="fa flm fa-angle-down"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('defenders')); ?>">Human Rights Cases</a></li>
                            <li><a href="<?php echo e(route('cookies')); ?>">Cookies Policy</a></li>
                            <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                            <li><a href="<?php echo e(route('terms')); ?>">Terms of Use</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <form action="<?php echo e(route('search')); ?>" class="header--search-form float--right" method="get">
                <input type="search" name="search" placeholder="Search..." class="header--search-control form-control" required>

                <button type="submit" class="header--search-btn btn"><i class="header--search-icon fa fa-search"></i></button>
            </form>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/inc/nav.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                    <div class="main--content col-md-8" data-sticky-content="true">
                        <div class="sticky-content-inner">
                            <div class="post--item post--single post--title-largest pd--30-0">
                                <div class="post--cats">
                                    <ul class="nav">
                                        <li><span><i class="fa fa-folder-open-o"></i></span></li>
                                        <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route("blog.search", $category->category)); ?>"><?php echo e(str_replace("_", ' ', $category->category)); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                <div class="post--info">
                                    <ul class="nav meta">
                                        <li><a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a></li>
                                        <li><a><?php echo e($post->created_at->diffForHumans()); ?></a></li>
                                    </ul>

                                    <div class="title">
                                        <h2 class="h4"><?php echo e($post->title); ?></h2>
                                    </div>
                                </div>

                                <div class="post--img">
                                    <a href="#" class="thumb"><img src="<?php echo e($post->featuredImage()); ?>" alt=""></a>
                                    <a href="#" class="icon"><i class="fa fa-star-o"></i></a>

                                    <div class="post--map">
                                        <div class="map--wrapper">
                                            <div data-map-latitude="23.790546" data-map-longitude="90.375583" data-map-zoom="6" data-map-marker="[[23.790546, 90.375583]]"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="post--content">
                                    <?php echo $post->body; ?>

                                </div>
                            </div>

                            <div class="post--tags">
                                <ul class="nav">
                                    <li><span><i class="fa fa-tags"></i></span></li>
                                    <?php $__currentLoopData = $post->tags(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route("blog.search", $tag)); ?>"><?php echo e($tag); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <div class="post--social pbottom--30">
                                <span class="title"><i class="fa fa-share-alt"></i></span>
                                
                                <div class="social--widget style--4">
                                    <ul class="nav">
                                        <div class="sharethis-inline-share-buttons"></div>
                                    </ul>
                                </div>
                            </div>

                            <div class="post--author-info clearfix">
                                <div class="img">
                                    <div class="vc--parent">
                                        <div class="vc--child">
                                            <a href="author-boxed.html" class="btn-link">
                                                <img src="<?php echo e($post->user->profile->thumbnail()); ?>" alt="">
                                                <p class="name"><?php echo e($post->user->name); ?></p>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="info">
                                    <h2 class="h4">About The Author</h2>

                                    <div class="content">
                                        <p><?php echo e($post->user->bio()); ?></p>
                                    </div>

                                    <ul class="social nav">
                                        <li><a href="<?php echo e($post->user->facebook()); ?>"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="<?php echo e($post->user->twitter()); ?>"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="<?php echo e($post->user->linkedin()); ?>"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="post--related ptop--30">
                                <div class="post--items-title" data-ajax="tab">
                                    <h2 class="h4">You Might Also Like</h2>
                                </div>

                                <div class="post--items post--items-2" data-ajax-content="outer">
                                    <ul class="nav row" data-ajax-content="inner">
                                        <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="col-sm-6 pbottom--30">
                                                <?php echo $__env->make("inc.post-format-one", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>

                            <div class="comment--list pd--30-0">
                                <div class="post--items-title">
                                    <h2 class="h4">Comments</h2>

                                    <i class="icon fa fa-comments-o"></i>
                                </div>

                                <div class="fb-comments" data-href="<?php echo e(Request::url()); ?>" data-numposts="5" data-width="100%"></div>
                            </div>

                        </div>
                    </div>

                <div class="main--sidebar col-md-4 col-sm-5 ptop--30 pbottom--30" data-sticky-content="true">
                    <div class="sticky-content-inner">
                        <?php echo $__env->make('inc.blog-search-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('inc.all_categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('inc.socials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('inc.newsletter-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('inc.recent_posts_widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5f5e0dbfa86c6e0012410fe2&product=inline-share-buttons" async="async"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/blog-show.blade.php ENDPATH**/ ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      	<h4 class="card-title">
        	<?php echo e($pageTitle); ?>

          <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary btn-sm float-right">Add New</a>
      	</h4>
    </div>
    <div class="card-body">
      	<div class="table-responsive">
        	<table class="table table-hover table-sm table-striped" id="data-table">
          		<thead class="thead-dark">
           	 		<tr>
	              		<th scope="col" class="text-center">#</th>
                    <th scope="col" class="text-center">Title</th>
                    <th scope="col" class="text-center">Categories</th>
              			<th scope="col" class="text-center">Created By</th>
              			<th scope="col" class="text-center">Last Updated</th>
              			<th scope="col" class="text-center">Actions</th>
            		</tr>
          		</thead>
          	<tbody>
              <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th class="align-middle text-center" scope="row"><?php echo e($post->id); ?></th>
                    <td><?php echo Str::limit($post->title, 40); ?></th>
                    <td>
                      <select class="custom-select">
                        <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option <?php if($loop->first): ?> selected="" <?php endif; ?>><?php echo e(ucwords(str_replace("_", ' ', $category->category))); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </th>
                    <td><?php echo e($post->user->name); ?></th>
                    <td><?php echo e($post->updated_at->diffForHumans()); ?></th>
                    <td class="align-middle text-center">
                      <a href="<?php echo e(route('admin.posts.show', $post->id)); ?>" class="btn btn-sm btn-primary">Show</a>
                      <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                      <button onclick="confirmDelete('<?php echo e(route('admin.posts.destroy', $post->id)); ?>')" class="btn btn-sm btn-danger">Delete</button>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7">No posts found. Click <a href="<?php echo e(route('admin.posts.create')); ?>">this link</a> to create new.</td>
                </tr>
              <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
      $(document).ready(function() {
          $('#data-table').DataTable( {
              "order": [[ 0, "desc" ]]
          } );
      } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>
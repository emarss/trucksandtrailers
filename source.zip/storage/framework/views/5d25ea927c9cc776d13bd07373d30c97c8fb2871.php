<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">
                        <?php if(isset($search)): ?>
                            <h2 class="text-dark font-weight-bold text-8">Results for "<?php echo e(ucwords(str_replace('_', ' ', $search))); ?>"</h2>
                        <?php else: ?>
                            <h2 class="text-dark font-weight-bold text-8">Check out our Latest News!</h2>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                            <li class="active">Search</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-4">

            <div class="row">
                <div class="col">
                    <div class="blog-posts">

                        <div class="row">

                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <article class="post post-medium border-0 pb-0 mb-5">
                                    <div class="post-image">
                                        <a href="<?php echo e(route('blog.show', $post->slug)); ?>">
                                            <img src="<?php echo e($post->featuredImage()); ?>"
                                                class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0"
                                                alt="<?php echo e($post->title); ?>" />
                                        </a>
                                    </div>

                                    <div class="post-content">

                                        <h2 class="font-weight-semibold text-4 line-height-6 mt-3 mb-2"><a
                                                href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e(Str::limit($post->title, 60)); ?></a></h2>
                                        <p><?php echo e($post->except()); ?></p>

                                        <div class="post-meta">
                                            <span><i class="far fa-user"></i> By <a href="<?php echo e(route('blog.user', $post->user_id)); ?>"><?php echo e($post->user->name); ?></a> </span>
                                            <span><i class="far fa-folder"></i>
                                                <?php $__currentLoopData = $post->categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('search.category', $category->category)); ?>"><?php echo e(ucwords(str_replace('_', ' ', $category->category))); ?></a>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </span>
                                            <span class="d-block mt-2"><a href="<?php echo e(route('blog.show', $post->slug)); ?>"
                                                    class="btn btn-xs btn-light text-1 text-uppercase">Read
                                                    More</a></span>
                                        </div>

                                    </div>
                                </article>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <div class="row">
                            <div class="col">
                                <?php echo e($posts->links()); ?>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/blog.blade.php ENDPATH**/ ?>
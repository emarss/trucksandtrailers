
<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/css/vendor-summernote.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
      </div>
      <div class="card-body">
        <form method="post" action="<?php echo e(route('admin.videos.categories.update', $category->id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label class="form-control-label" for="category">Category Name</label>
            <input value="<?php echo e($category->category); ?>" required="" type="text" name="category" class="form-control" placeholder="Category name">
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-control-label" for="description">Category Description</label>
            <textarea name="description" class="text-editor"><?php echo $category->description; ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger my-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('admin/vendor/summernote-bs4.min.js')); ?>"></script>

    <script>
        $('.text-editor').summernote({
            height: '200',
            dialogsInBody: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/videos/categories/edit.blade.php ENDPATH**/ ?>
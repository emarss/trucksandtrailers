

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <form method="post" action="<?php echo e(route('admin.users.update', $user->id)); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Basic Details</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-6">
              <label class="form-control-label" for="name">Full Name *</label>
              <input value="<?php echo e($user->name); ?>" required="" type="text" class="form-control" name="name">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-6">
              <label class="form-control-label" for="email">Email *</label>
              <input value="<?php echo e($user->email); ?>" required="" type="email" class="form-control" name="email">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>                    
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Additional Info</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-6">
              <label class="form-control-label" for="role">Role</label>
              <select class="form-control custom-select" name="role" required="">
                <option value="">Select option</option>
                <option <?php echo e($user->profile->role == 'admin' ? "selected" : ''); ?> value="admin">Admin</option>
                <option <?php echo e($user->profile->role == 'author' ? "selected" : ''); ?> value="author">Author</option>
                <option <?php echo e($user->profile->role == 'moderator' ? "selected" : ''); ?> value="moderator">Moderator</option>
              </select>
              <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-6">
              <label class="form-control-label" for="national_id">National Id</label>
              <input value="<?php echo e($user->profile->national_id); ?>" type="text" class="form-control" name="national_id">
              <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-8">
              <label class="form-control-label" for="address">Address</label>
              <input value="<?php echo e($user->profile->address); ?>" type="text" class="form-control" name="address">
              <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-4">
              <label class="form-control-label" for="cell_number">Cell Number</label>
              <input value="<?php echo e($user->profile->cell_number); ?>" type="text" class="form-control" name="cell_number">
              <?php $__errorArgs = ['cell_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-12">
              <label class="form-control-label" for="bio">Short Bio</label>
              <textarea name="bio" value="<?php echo e($user->profile->bio); ?>" cols="30" rows="5" class="form-control"></textarea>
              <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>                    
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">More Info</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-4">
              <label class="form-control-label" for="facebook">Facebook Link</label>
              <input value="<?php echo e($user->profile->facebook); ?>" type="url" class="form-control" name="facebook">
              <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-4">
              <label class="form-control-label" for="twitter">Twitter Link</label>
              <input value="<?php echo e($user->profile->twitter); ?>" type="url" class="form-control" name="twitter">
              <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-4">
              <label class="form-control-label" for="linkedin">LinkedIn Link</label>
              <input value="<?php echo e($user->profile->linkedin); ?>" type="url" class="form-control" name="linkedin">
              <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-8">
              <label class="form-control-label" for="avatar">Account Avatar</label>
              <div class="custom-file">
                <input value="<?php echo e(old('avatar')); ?>" type="file" accept="image/*" class="custom-file-input" name="avatar">
                <label class="custom-file-label" for="avatar">Choose file</label>
              </div>
              <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-4">
              <div class="row">
                <div class="col-12 text-center">
                  <img src="<?php echo e($user->profile->thumbnail()); ?>" style="max-height: 40px" class="avatar rounder-circle">
                </div>
                <div class="col-12 text-center">
                  <small class="text-info">Current Avatar</small>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>                    
        </div>
      </div>      
  </form>
  <form action="<?php echo e(route('admin.password', $user->id)); ?>" class="form" method="post">
    <?php echo csrf_field(); ?>
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Change Password</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-6">
              <label class="form-control-label" for="password">New Password</label>
              <input type="password" class="form-control" onautocomplete="new-password" name="password">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger my-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-6">
              <label class="form-control-label" for="password_confirmation">Password Repeat</label>
              <input type="password" class="form-control" onautocomplete="new-password" name="password_confirmation">
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Submit</button>
          </div>
        </div>
      </div>    
  </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>
<!-- ==== jQuery Library ==== -->
<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>

<!-- ==== Bootstrap Framework ==== -->
<script defer src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!-- ==== StickyJS Plugin ==== -->
<script defer src="<?php echo e(asset('js/jquery.sticky.min.js')); ?>"></script>

<!-- ==== HoverIntent Plugin ==== -->
<script defer src="<?php echo e(asset('js/jquery.hoverIntent.min.js')); ?>"></script>

<!-- ==== Marquee Plugin ==== -->
<script defer src="<?php echo e(asset('js/jquery.marquee.min.js')); ?>"></script>

<!-- ==== Validation Plugin ==== -->
<script defer src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>

<!-- ==== Isotope Plugin ==== -->
<script defer src="<?php echo e(asset('js/isotope.min.js')); ?>"></script>

<!-- ==== Resize Sensor Plugin ==== -->
<script defer src="<?php echo e(asset('js/resizesensor.min.js')); ?>"></script>

<!-- ==== Sticky Sidebar Plugin ==== -->
<script defer src="<?php echo e(asset('js/theia-sticky-sidebar.min.js')); ?>"></script>

<!-- ==== Zoom Plugin ==== -->


<!-- ==== Bar Rating Plugin ==== -->


<!-- ==== Countdown Plugin ==== -->

<!-- ==== RetinaJS Plugin ==== -->
<script defer src="<?php echo e(asset('js/retina.min.js')); ?>"></script>

<!-- ==== Main JavaScript ==== -->
<script defer src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php /**PATH C:\Users\Carter\Projects\work\ZHRMP\source\resources\views/inc/scripts.blade.php ENDPATH**/ ?>
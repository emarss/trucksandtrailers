
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="Emarss Technologies, Digital Solutions, Mobile Apps, Mobile Applications, Business Manager App, Student Companion App, App Development, Website Development" />
<meta name="description" content="Offering quality & affordable digital solutions- from Mobile Apps, Websites & Web Apps.">
<meta name="author" content="emarss.co.zw">

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('/img/logos/logo-only.png')); ?>" type="image/x-icon" />
<link rel="apple-touch-icon" href="<?php echo e(asset('/img/logos/logo-only.png')); ?>">

<!-- Mobile Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">

<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light%7CPlayfair+Display:400&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/animate/animate.compat.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/simple-line-icons/css/simple-line-icons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/owl.carousel/assets/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/magnific-popup/magnific-popup.min.css')); ?>">
<!-- Revolution Slider Addon - Typewriter -->
<link rel="stylesheet" type="text/css" href="/vendor/rs-plugin/revolution-addons/typewriter/css/typewriter.css" />

<!-- Theme CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/css/theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/theme-elements.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/theme-blog.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/theme-shop.css')); ?>">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="<?php echo e(asset('/css/skins/skin-corporate-15.css')); ?>">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/css/custom.css')); ?>">

<!-- Head Libs -->
<script src="<?php echo e(asset('/vendor/modernizr/modernizr.min.js')); ?>"></script>

<meta property="og:url" content="<?php echo e(Request::url()); ?>" />
<meta property="og:title" content="<?php echo e("Emarss Technologies | $pageTitle"); ?>" />
<?php if(!Request::is("blog/*")): ?>
    <meta property="og:type" content="website" />
    <meta property="og:description" content="Offering quality & affordable digital solutions- from Mobile Apps, Websites & Web Apps." />
    <meta property="og:image" content="<?php echo e(asset('img/logo-linear.png')); ?>" />
<?php else: ?>
    <meta property="og:type" content="article" />
    <meta property="og:description" content="<?php echo e($post->except()); ?>" />
    <meta property="og:image" content="<?php echo e($post->featuredImage()); ?>" />
<?php endif; ?>

<!-- Matomo -->
<script type="text/javascript">
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="https://analytics.emarss.co.zw/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '2']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code --><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/includes/head.blade.php ENDPATH**/ ?>
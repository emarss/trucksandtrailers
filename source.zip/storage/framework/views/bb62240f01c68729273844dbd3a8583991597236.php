<?php $__env->startSection('content'); ?>
    <!-- Main Content Section Start -->
    <div class="main-content--section pbottom--30">
        <div class="container">
            <div class="row">
                <!-- Main Content Start -->
                <div class="main--content col-md-12" data-sticky-content="true">
                    <div class="sticky-content-inner">
                        <!-- Post Items Start -->
                        <div class="post--items post--items-2 pd--30-0">
                            <h2><?php echo e(ucwords(str_replace("_", " ", $pageTitle))); ?></h2><hr>
                            <ul class="nav row AdjustRow">
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-md-4 mb-5 pb-5 col-sm-12 col-xs-6 col-xss-12">
                                        <?php echo $__env->make("inc.post-format-one", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Post Items End -->

                        <!-- Pagination Start -->
                        <div class="pagination--wrapper clearfix bdtop--1 bd--color-2 ptop--60 pbottom--30">
                            <?php echo e($posts->links()); ?>

                        </div>
                        <!-- Pagination End -->
                    </div>
                </div>
                <!-- Main Content End -->
            </div>
        </div>
    </div>
    <!-- Main Content Section End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/search-posts.blade.php ENDPATH**/ ?>
<section class="call-to-action call-to-action-default with-button-arrow content-align-center call-to-action-in-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-lg-9">
                <div class="call-to-action-content">
                    <h2 class="font-weight-normal text-6 mb-0">Emarss Technologies is your parnter <strong class="font-weight-extra-bold">in Digital Solutions</strong>!</h2>
                    <p class="mb-0">We help your grow your business through digital solutions.</p>
                </div>
            </div>
            <div class="col-md-3 col-lg-3">
                <div class="call-to-action-btn">
                    <a href="<?php echo e(route('contact')); ?>" target="_blank" class="btn btn-dark btn-lg text-3 font-weight-semibold px-4 py-3">Get Started Now</a><span class="arrow hlb d-none d-md-block" data-appear-animation="rotateInUpLeft"
                        style="top: -40px; left: 70%;"></span>
                </div>
            </div>
        </div>
    </div>
</section>
<footer id="footer" class="mt-0 bg-color-light-scale-1 border-0">
    <div class="container">
        <div class="row py-5 justify-content-center">
            <div class="col-md-9 offset-md-1 offset-lg-0 mb-4 mb-lg-0 d-flex align-items-center">
                <div class="footer-nav footer-nav-links footer-nav-bottom-line">
                    <nav>
                        <ul class="nav" id="footerNav">
                            <li>
                                <a href="<?php echo e(route('home')); ?>" class="text-color-dark active">Home</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('services')); ?>" class="text-color-dark">Services</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('projects')); ?>" class="text-color-dark">Projects</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('blog')); ?>" class="text-color-dark">Blog</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('about')); ?>" class="text-color-dark">About Us</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('careers')); ?>" class="text-color-dark">Careers</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('contact')); ?>" class="text-color-dark">Contact Us</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 mb-4 mb-lg-0 text-center text-lg-right">
                <h5 class="text-3 text-color-dark mb-0 pb-1 opacity-6">CONTACT US</h5>
                <a href="tel:+263774671339" class="text-8 text-color-dark text-color-hover-primary text-decoration-none font-weight-bold pb-1 mb-0">+263
                    77 467 1339</a>
                <p class="m-0"><a href="mailto:info@emarss.co.zw" class="text-color-dark text-color-hover-primary">info@emarss.co.zw</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright footer-copyright-style-2 bg-color-light-scale-1 footer-top-border">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col-lg-1 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
                    <a href="<?php echo e(route('home')); ?>" class="logo pr-0 pr-lg-3">
                        <img alt="Emarss Technologies" src="<?php echo e(asset('img/logos/logo-only.png')); ?>" height="50">
                    </a>
                </div>
                <div class="col-lg-11 d-flex align-items-center justify-content-center justify-content-lg-end mb-4 mb-lg-0">
                    <p>&copy; Copyright <?php echo e(now()->year); ?>. All Rights Reserved by Emarss Technologies.</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/includes/footer.blade.php ENDPATH**/ ?>
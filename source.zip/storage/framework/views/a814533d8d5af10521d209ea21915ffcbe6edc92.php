<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div role="main" class="main">

        <section class="page-header page-header-modern page-header-md bg-transparent m-0">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">


                        <h1 class="text-dark text-10"><strong>Careers</strong></h1>
                        <span class="sub-title text-dark">We're always looking for rockstars</span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="active">Pages</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <hr class="m-0">

        <div class="container py-5 mt-3">

            <div class="row">
                <div class="col-lg-8">
                    <div class="overflow-hidden mb-2">
                        <h2 class="font-weight-normal text-7 mb-2 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">Find Your <strong class="font-weight-extra-bold">Oportunity</strong></h2>
                    </div>
                    <div class="overflow-hidden mb-4">
                        <p class="lead mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">Emarss Technologies is a very dynamic place. We are always looking for people who are constantly learning, who are instinctively finding ways to create value and think ahead. People who can anticipate and throw out ideas of what we could be doing next to create value.</p>
                    </div>
                    <p class="text-color-light-3 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="600">At Emarss, we also emphasize strongly on passion. We always say to each other, "If you’re not passionate about it, don’t do it." We all don’t have to be passionate about the product. We all don’t have to be passionate about each other. But your passion to be part of a company has to spring from somewhere.</p>
                    <p class="text-color-light-3 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">If you would like to join us in digitalizing Africa, and if you think you have the drive and the passion, email your CV to <a href="mailto:jobs@emarss.co.zw">jobs@emarss.co.zw</a> .</p>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial testimonial-primary appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800">
                        <blockquote>
                            <p class="mb-0">Forget about the fast lane. If you really want to fly, harness your power to your passion. Honor your calling. Everybody has one. Trust your heart, and success will come to you <br><b>Oprah Winfrey</b>.</p>
                        </blockquote>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/careers.blade.php ENDPATH**/ ?>
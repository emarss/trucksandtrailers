<ul class="nav row gutter--15" data-ajax-content="inner" id="lightgallery">
  <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="col-md-3 col-xs-6 col-xxs-12" data-src="<?php echo $photo->getPath(); ?>"data-sub-html="<?php echo $photo->description; ?>">
      <div class="post--item post--layout-1">
        <div class="post--img">
          <a class="thumb" href="<?php echo e($photo->thumbnail()); ?>"><img src="<?php echo e($photo->thumbnail()); ?>"></a>

          <div class="post--info">
            <ul class="nav meta">
              <li><a><?php echo e($photo->created_at->diffForHumans()); ?></a></li>
            </ul>

            <div class="title">
              <h2 class="h4"><a class="btn-link"><?php echo Str::limit($photo->description, 50); ?></a></h2>
            </div>
          </div>
        </div>
      </div>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="post--img"><div class="post--info"><div class="text-info">No content available at the moment, please, try again later.</div></div></div>
  <?php endif; ?>
</ul><?php /**PATH C:\Users\Emarss\work\ZHRMP\source\resources\views/inc/photos-partial.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title',  $pageTitle ); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 align-self-center p-static order-2 text-center">


                        <h1 class="text-dark font-weight-bold text-8">Our Projects</h1>
                        <span class="sub-title text-dark">What We Have Been Upto!</span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">


                        <ul class="breadcrumb d-block text-center">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="active">Projects</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <div class="container py-2">

            <div class="mt-3">
                <div class="row portfolio-list">

                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="portfolio-item">
                                <a href="<?php echo e(route('projects.show', $project->slug)); ?>">
                                    <span
                                        class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation"
                                        data-appear-animation="fadeIn" data-appear-animation-delay="100">
                                        <span class="thumb-info-wrapper border-radius-0">
                                            <img src="<?php echo e($project->thumbnail()); ?>" class="img-fluid border-radius-0"
                                                alt="">
                                            <span class="thumb-info-action">
                                                <span class="thumb-info-action-icon bg-dark opacity-8"><i
                                                        class="fas fa-plus"></i></span>
                                            </span>
                                        </span>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6">

                            <div class="overflow-hidden">
                                <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="btn-link">
                                    <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation"
                                        data-appear-animation="maskUp" data-appear-animation-delay="600">
                                        <?php echo e($project->title); ?>

                                    </h2>
                                </a>
                            </div>

                            <p class="appear-animation" data-appear-animation="fadeInUpShorter"
                                data-appear-animation-delay="800"><?php echo e($project->except(250)); ?> </p>

                            <ul class="list list-icons list-primary list-borders text-2 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                <li><i class="fas fa-caret-right left-10"></i> <strong
                                        class="text-color-primary">Project URL:</strong> <a href="<?php echo e($project->url); ?>"
                                        class="btn-link"><?php echo e($project->url); ?></a></li>
                                <li><i class="fas fa-caret-right left-10"></i> <strong
                                        class="text-color-primary">Date:</strong> <?php echo e($project->date->format('M, Y')); ?>

                                </li>
                                <li><i class="fas fa-caret-right left-10"></i> <strong
                                        class="text-color-primary">Skills:</strong>
                                    <?php $__currentLoopData = $project->skills(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span
                                            class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1"><?php echo e($skill); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </li>
                            </ul>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo e($projects->links()); ?>

                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/projects.blade.php ENDPATH**/ ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      	<h4 class="card-title">
        	<?php echo e($pageTitle); ?>

      	</h4>
    </div>
    <div class="card-body">
      	<div class="table-responsive">
        	<table class="table table-hover table-sm table-striped" id="data-table">
          		<thead class="thead-dark">
           	 		<tr>
	              		<th scope="col" class="text-center">#</th>
                    <th scope="col" class="text-center">Name</th>
                    <th scope="col" class="text-center">Email</th>
              			<th scope="col" class="text-center">Website</th>
              			<th scope="col" class="text-center">Created At</th>
              			<th scope="col" class="text-center">Last Updated</th>
              			<th scope="col" class="text-center">Actions</th>
            		</tr>
          		</thead>
          	<tbody>
              <?php $__empty_1 = true; $__currentLoopData = $feedbackMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th class="align-middle text-center" scope="row"><?php echo e($feedback->id); ?></th>
                    <td><?php echo e($feedback->name); ?></th>
                    <td><?php echo e($feedback->email); ?></th>
                    <td><a href="<?php echo e($feedback->website); ?>"><?php echo e($feedback->website); ?></a></th>
                    <td><?php echo e($feedback->created_at->diffForHumans()); ?></th>
                    <td><?php echo e($feedback->updated_at->diffForHumans()); ?></th>
                    <td class="align-middle text-center">
                      <a href="<?php echo e(route('admin.feedback.show', $feedback->id)); ?>" class="btn btn-sm btn-primary">Show</a>
                      <button onclick="confirmDelete('<?php echo e(route('admin.feedback.destroy', $feedback->id)); ?>')" class="btn btn-sm btn-danger">Delete</button>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7">No feedback messages found.</td>
                </tr>
              <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
      $(document).ready(function() {
          $('#data-table').DataTable( {
              "order": [[ 0, "desc" ]]
          } );
      } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarss/Projects/Dawn/emarss/source/resources/views/admin/feedback/index.blade.php ENDPATH**/ ?>